"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var pgColorAndHtml_1 = __importDefault(require("generated/pages/pgColorAndHtml"));
var color_1 = __importDefault(require("@smartface/native/ui/color"));
var color_2 = __importDefault(require("@smartface/extension-utils/lib/color"));
var guid_1 = __importDefault(require("@smartface/extension-utils/lib/guid"));
var html_to_text_1 = require("@smartface/extension-utils/lib/html-to-text");
var attributedstring_1 = __importDefault(require("@smartface/native/ui/attributedstring"));
var sfCorePropFactory_1 = __importDefault(require("@smartface/contx/lib/smartface/sfCorePropFactory"));
var theme_1 = require("theme");
var mixins_1 = require("@smartface/mixins");
var font_1 = __importDefault(require("@smartface/native/ui/font"));
var exampleHtml = '<span style="font-size: 24px; color: rgb(0, 0, 0); text-decoration-color: rgb(0, 0, 0);"><span style="font-family: Nunito-LightItalic; font-size: 24px; background-color: transparent; color: rgb(0, 0, 0); text-decoration-color: rgb(0, 0, 0);">Your </span><font face="ios-Default-Bold" style="font-size: 24px; font-family: ios-Default-Regular; background-color: transparent; color: rgb(0, 0, 0); text-decoration-color: rgb(0, 0, 0);">attributed </font><span style="text-decoration-line: underline; color: rgb(139, 87, 42); font-size: 24px; font-family: ios-Default-Regular; background-color: transparent; text-decoration-color: rgb(0, 0, 0);">Stri<span style="color: rgb(139, 87, 42); text-decoration-line: underline ; text-decoration-color: rgb(0, 0, 0); font-size: 24px; font-family: ios-Default-Regular; background-color: transparent;">ngs</span></span></span><div><span style="font-size: 16px; font-family: ios-Default-Regular; text-decoration-color: rgb(0, 0, 0);"><span style="text-decoration-line: underline; font-size: 16px; font-family: ios-Default-Regular; text-decoration-color: rgb(0, 0, 0);"><span style="text-decoration-line: underline; text-decoration-color: rgb(0, 0, 0); font-size: 24px; font-family: ios-Default-Regular; background-color: rgb(189, 16, 224);">second</span></span></span></div><div><span style="font-size: 16px; font-family: ios-Default-Regular; text-decoration-color: rgb(0, 0, 0);"><span style="text-decoration-line: underline; font-size: 16px; font-family: ios-Default-Regular; text-decoration-color: rgb(0, 0, 0);"><span style="text-decoration-line: underline; text-decoration-color: rgb(0, 0, 0); font-size: 16px; font-family: ios-Default-Regular; background-color: rgb(189, 16, 224); color: rgb(248, 231, 28);">Third</span></span></span></div>';
var PgColorAndHtml = /** @class */ (function (_super) {
    __extends(PgColorAndHtml, _super);
    function PgColorAndHtml(router, route) {
        var _this = _super.call(this, {}) || this;
        _this.router = router;
        _this.route = route;
        return _this;
    }
    PgColorAndHtml.prototype.initTouchButton = function () {
        this.flTouch.on('touch', function () { return console.log('pressed'); });
    };
    PgColorAndHtml.prototype.initTextBoxes = function () {
        this.tbR.onTextChanged = this.onRgbTextBoxTextChanged.bind(this);
        this.tbG.onTextChanged = this.onRgbTextBoxTextChanged.bind(this);
        this.tbB.onTextChanged = this.onRgbTextBoxTextChanged.bind(this);
        this.onRgbTextBoxTextChanged();
    };
    PgColorAndHtml.prototype.onRgbTextBoxTextChanged = function () {
        var r = parseInt(this.tbR.text) || 0;
        var g = parseInt(this.tbG.text) || 0;
        var b = parseInt(this.tbB.text) || 0;
        var color = color_1.default.create(r, g, b);
        var colorValues = this.getColorValues(color);
        this.updateRgbTextBoxes(r, g, b);
        this.updateRgbLabels(colorValues);
    };
    PgColorAndHtml.prototype.getColorValues = function (color) {
        var rgb = color_2.default.rgb(color);
        var rgba = color_2.default.rgba(color);
        var argb = color_2.default.argb(color);
        var tinycolor = color_2.default.tinycolor(color);
        return {
            rgb: rgb,
            rgba: rgba,
            argb: argb,
            tinycolor: tinycolor
        };
    };
    PgColorAndHtml.prototype.updateRgbLabels = function (values) {
        var rgb = values.rgb, rgba = values.rgba, argb = values.argb, tinycolor = values.tinycolor;
        this.lblValueRgb.text = '#' + rgb;
        this.lblValueRgba.text = '#' + rgba;
        this.lblValueArgb.text = '#' + argb;
        this.lblValueTinyColor.text = tinycolor;
    };
    PgColorAndHtml.prototype.updateRgbTextBoxes = function (r, g, b) {
        this.tbR.text = r.toString();
        this.tbG.text = g.toString();
        this.tbB.text = b.toString();
    };
    PgColorAndHtml.prototype.initGuid = function () {
        var _this = this;
        this.lblGuid.onTouch = function () {
            _this.createAndUpdateGuid();
            return true;
        };
        this.createAndUpdateGuid();
    };
    PgColorAndHtml.prototype.createAndUpdateGuid = function () {
        var guid = (0, guid_1.default)();
        this.lblGuid.text = guid;
    };
    PgColorAndHtml.prototype.initHtml = function () {
        var _this = this;
        this.taHtml.text = exampleHtml;
        this.tvHtml.scrollEnabled = false;
        this.btnAttrTexts.onTouch = function () {
            _this.createAndShowAttributedTexts();
            return false;
        };
        this.btnAttrStr.onTouch = function () {
            _this.createAndShowAttributedStrs();
            return false;
        };
    };
    PgColorAndHtml.prototype.createAndShowAttributedTexts = function () {
        var attributedStrings = (0, html_to_text_1.createAttributedTexts)(this.taHtml.text);
        console.log('createAndShowAttributedTexts: ', attributedStrings);
        this.tvHtml.attributedText = attributedStrings;
    };
    PgColorAndHtml.prototype.createAndShowAttributedStrs = function () {
        var attributedStrings = (0, html_to_text_1.createAttributedStrings)(this.taHtml.text);
        console.log('createAndShowAttributedStrs: ', attributedStrings);
        this.tvHtml.attributedText = attributedStrings.map(function (s) { return new attributedstring_1.default((0, sfCorePropFactory_1.default)(s)); });
    };
    PgColorAndHtml.prototype.initGetNativeStyle = function () {
        var backgroundColor = theme_1.themeService.getNativeStyle('.getNativeStyleTest').backgroundColor;
        this.btnGetNativeStyle.backgroundColor = backgroundColor;
    };
    PgColorAndHtml.prototype.initNativeTypescriptTest = function () {
        // AttributedString & Color TEST
        var attributeString = new attributedstring_1.default();
        attributeString.string = ' Third - AttributedString';
        attributeString.link = 'https://www.google.com/';
        attributeString.strikethrough = true;
        attributeString.backgroundColor = color_1.default.RED;
        attributeString.foregroundColor = color_1.default.GREEN;
        attributeString.underline = true;
        attributeString.font = font_1.default.create('Times New Roman', 30, font_1.default.NORMAL);
        attributeString.ios.underlineColor = color_1.default.BLUE;
        attributeString.ios.strikethroughColor = color_1.default.WHITE;
        this.tvAttrString.attributedText = [attributeString];
        this.tvAttrString.on('linkClick', function () {
            console.log('Textview LinkClick test');
        });
        this.btnGradientColor.backgroundColor = color_1.default.createGradient({
            direction: color_1.default.GradientDirection.DIAGONAL_LEFT,
            startColor: color_1.default.RED,
            endColor: color_1.default.BLACK
        });
    };
    PgColorAndHtml.prototype.onShow = function () {
        _super.prototype.onShow.call(this);
        this.initBackButton(this.router);
    };
    PgColorAndHtml.prototype.onLoad = function () {
        _super.prototype.onLoad.call(this);
        this.initTouchButton();
        this.initTextBoxes();
        this.initGuid();
        this.initHtml();
        this.initGetNativeStyle();
        this.initNativeTypescriptTest();
    };
    return PgColorAndHtml;
}((0, mixins_1.withDismissAndBackButton)(pgColorAndHtml_1.default)));
exports.default = PgColorAndHtml;
//# sourceMappingURL=pgColorAndHtml.js.map