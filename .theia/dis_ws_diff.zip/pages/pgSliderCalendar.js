"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var pgSliderCalendar_1 = __importDefault(require("generated/pages/pgSliderCalendar"));
var mixins_1 = require("@smartface/mixins");
var screen_1 = __importDefault(require("@smartface/native/device/screen"));
var component_calendar_1 = require("@smartface/component-calendar");
var PgSliderCalendar = /** @class */ (function (_super) {
    __extends(PgSliderCalendar, _super);
    function PgSliderCalendar(router, route) {
        var _this = _super.call(this, {}) || this;
        _this.router = router;
        _this.route = route;
        _this.scrollState = { startX: 0, endX: 0 };
        _this.c = new component_calendar_1.CalendarCore();
        _this.c.changeCalendar("tr", "gregorian");
        _this.c.subscribe(function (oldState, newState) {
        });
        _this.c.setDate({
            day: new Date().getDate(),
            month: new Date().getMonth() + 1,
            year: new Date().getFullYear()
        });
        _this.c.now();
        _this.gvMain.on('scroll', function () {
        });
        _this.gvMain.on('scrollStateChanged', function (scrollState, contentOffset) {
            if (scrollState == 1) {
                _this.scrollState.startX = contentOffset.x;
            }
            if (_this.scrollState.startX != 0 && scrollState == 2) {
                _this.scrollState.endX = contentOffset.x;
                if (_this.scrollState.startX > _this.scrollState.endX) {
                    _this.prevWeek();
                }
                if (_this.scrollState.startX < _this.scrollState.endX) {
                    _this.nextWeek();
                }
                else {
                    "dont change";
                }
            }
            if (scrollState == 0) {
                _this.scrollState = { startX: 0, endX: 0 };
            }
        });
        return _this;
    }
    PgSliderCalendar.prototype.prevWeek = function () {
        this.c.prevWeek();
        var currentDate = this.c.getState().selectedDays[0].localeDate;
        var tarih = new Date("".concat(currentDate.year, "-").concat(currentDate.month, "-").concat(currentDate.day));
        tarih.setDate(tarih.getDate() - 7);
        this.c.setSelectedDate({
            day: tarih.getDate(),
            month: tarih.getMonth() + 1,
            year: tarih.getFullYear()
        });
        this.refreshGridView();
        this.gvMain.scrollTo(1, true);
        this.lblFullDate.text = "".concat(this.getSelectedDay(), " ").concat(this.getSelectedMonthFullName(), " ").concat(this.getSelectedYear());
    };
    PgSliderCalendar.prototype.nextWeek = function () {
        console.log(this.c.getState());
        this.c.nextWeek();
        console.log(this.getCurrentWeek());
        var currentDate = this.c.getState().selectedDays[0].localeDate;
        var tarih = new Date("".concat(currentDate.year, "-").concat(currentDate.month, "-").concat(currentDate.day));
        tarih.setDate(tarih.getDate() + 7);
        this.c.setSelectedDate({
            day: tarih.getDate(),
            month: tarih.getMonth() + 1,
            year: tarih.getFullYear()
        });
        this.refreshGridView();
        this.gvMain.scrollTo(1, true);
        this.lblFullDate.text = "".concat(this.getSelectedDay(), " ").concat(this.getSelectedMonthFullName(), " ").concat(this.getSelectedYear());
    };
    PgSliderCalendar.prototype.refreshGridView = function () {
        this.gvMain.refreshData();
        this.gvMain.scrollTo(1, true);
    };
    PgSliderCalendar.prototype.getCurrentWeek = function () {
        return this.c.getState().weekIndex;
    };
    PgSliderCalendar.prototype.getSelectedYear = function () {
        return this.c.getState().selectedDays[0].date.year;
    };
    PgSliderCalendar.prototype.getSelectedDay = function () {
        return this.c.getState().selectedDays[0].date.day;
    };
    PgSliderCalendar.prototype.getSelectedMonthFullName = function () {
        return this.c.getState().selectedDays[0].daymonthInfo.longName;
    };
    PgSliderCalendar.prototype.setButtonOnGridView = function (gridViewItem, weekIndex) {
        var _this = this;
        this.c.getState().month.days[weekIndex].forEach(function (day, index) {
            var selectedDate = {
                day: day.day,
                month: _this.c.getState().month.date.month,
                year: _this.c.getState().month.date.year
            };
            if (day.month == "next") {
                selectedDate.month = _this.c.getState().month.nextMonth.date.month;
                selectedDate.year = _this.c.getState().month.nextMonth.date.year;
            }
            if (day.month == "previous") {
                selectedDate.month = _this.c.getState().month.previousMonth.date.month;
                selectedDate.year = _this.c.getState().month.previousMonth.date.year;
            }
            gridViewItem["_day".concat(index, "Click")] = function () {
                _this.c.setSelectedDate(selectedDate);
                gridViewItem.selectedDay = selectedDate;
                _this.lblFullDate.text = "".concat(_this.getSelectedDay(), " ").concat(_this.getSelectedMonthFullName(), " ").concat(_this.getSelectedYear());
            };
        });
    };
    PgSliderCalendar.prototype.setDaysOnGridView = function (gridViewItem, index) {
        if (index == 0) {
            if (this.getCurrentWeek() == 0) {
                var lastWeekIndexOnPrevMonth_1;
                var firstDateInWeek_1 = this.c.getState().month.days[0][0];
                this.c.prevWeek();
                this.c.getState().month.days.map(function (days, indexDays) {
                    days.map(function (day, indexDay) {
                        if ((day.day == firstDateInWeek_1.day) && indexDay == 0) {
                            lastWeekIndexOnPrevMonth_1 = indexDays;
                        }
                    });
                });
                gridViewItem.days = this.c.getState().month.days[lastWeekIndexOnPrevMonth_1 - 1];
                this.setButtonOnGridView(gridViewItem, 0);
                this.c.nextWeek();
            }
            else {
                gridViewItem.days = this.c.getState().month.days[this.getCurrentWeek() - 1];
                this.setButtonOnGridView(gridViewItem, this.getCurrentWeek() - 1);
            }
        }
        if (index == 1) {
            gridViewItem.days = this.c.getState().month.days[this.getCurrentWeek()];
            this.setButtonOnGridView(gridViewItem, this.getCurrentWeek());
            gridViewItem.selectedDay = this.c.getState().selectedDays[0].date;
        }
        if (index == 2) {
            gridViewItem.days = this.c.getState().month.days[this.getCurrentWeek() + 1];
            this.setButtonOnGridView(gridViewItem, this.getCurrentWeek() + 1);
        }
        this.lblFullDate.text = "".concat(this.getSelectedDay(), " ").concat(this.getSelectedMonthFullName(), " ").concat(this.getSelectedYear());
    };
    PgSliderCalendar.prototype.initGridView = function () {
        var _this = this;
        this.gvMain.refreshEnabled = false;
        this.gvMain.scrollBarEnabled = false;
        this.gvMain.itemCount = 3;
        this.gvMain.layoutManager.onItemLength = function () { return screen_1.default.width; };
        this.gvMain.paginationEnabled = true;
        this.gvMain.scrollTo(1, true);
        this.gvMain.onItemBind = function (gridViewItem, index) {
            _this.setDaysOnGridView(gridViewItem, index);
        };
    };
    PgSliderCalendar.prototype.setDaysName = function () {
        this.day0lbl.text = this.c.getState().month.daysMin[0];
        this.day1lbl.text = this.c.getState().month.daysMin[1];
        this.day2lbl.text = this.c.getState().month.daysMin[2];
        this.day3lbl.text = this.c.getState().month.daysMin[3];
        this.day4lbl.text = this.c.getState().month.daysMin[4];
        this.day5lbl.text = this.c.getState().month.daysMin[5];
        this.day6lbl.text = this.c.getState().month.daysMin[6];
    };
    PgSliderCalendar.prototype.onShow = function () {
        _super.prototype.onShow.call(this);
        this.initBackButton(this.router);
    };
    PgSliderCalendar.prototype.onLoad = function () {
        _super.prototype.onLoad.call(this);
        this.setDaysName();
        this.initGridView();
    };
    return PgSliderCalendar;
}((0, mixins_1.withDismissAndBackButton)(pgSliderCalendar_1.default)));
exports.default = PgSliderCalendar;
// if(this.getCurrentWeek() == 0){
//     let lastWeekIndexOnPrevMonth: number;
//     const firstDateInWeek = this.c.getState().month.days[0][0];
// this.c.prevWeek();
// this.c.getState().month.days.map((days, indexDays) => {
//  days.map((day, indexDay) => {
//      if ((day.day == firstDateInWeek.day) && indexDay == 0) {
//          lastWeekIndexOnPrevMonth = indexDays;
//      }
//  })
// });
// gridViewItem.days = this.c.getState().month.days[lastWeekIndexOnPrevMonth -1]
// this.c.nextWeek();
// }else{
//# sourceMappingURL=pgSliderCalendar.js.map