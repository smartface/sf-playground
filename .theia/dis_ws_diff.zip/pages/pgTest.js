"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var page1_1 = __importDefault(require("generated/pages/page1"));
var mixins_1 = require("@smartface/mixins");
var PgTest = /** @class */ (function (_super) {
    __extends(PgTest, _super);
    function PgTest(router, route) {
        var _this = _super.call(this, {}) || this;
        _this.router = router;
        _this.route = route;
        return _this;
    }
    PgTest.prototype.onShow = function () {
        _super.prototype.onShow.call(this);
        this.initBackButton(this.router);
    };
    PgTest.prototype.onLoad = function () {
        _super.prototype.onLoad.call(this);
    };
    return PgTest;
}((0, mixins_1.withDismissAndBackButton)(page1_1.default)));
exports.default = PgTest;
//# sourceMappingURL=pgTest.js.map