"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var pgSystem_1 = __importDefault(require("generated/pages/pgSystem"));
var mixins_1 = require("@smartface/mixins");
var system_1 = __importDefault(require("@smartface/native/device/system"));
var PgSystem = /** @class */ (function (_super) {
    __extends(PgSystem, _super);
    function PgSystem(router, route) {
        var _this = _super.call(this, {}) || this;
        _this.router = router;
        _this.route = route;
        return _this;
    }
    PgSystem.prototype.printSystem = function () {
        //SYSTEM TESTS
        console.log('Device.System.OS: ' + system_1.default.OS);
        console.log('Device.System.OSVersion: ' + system_1.default.OSVersion);
        console.log('Device.System.batteryLevel: ' + system_1.default.batteryLevel);
        console.log('Device.System.isBatteryCharged: ' + system_1.default.isBatteryCharged);
        console.log('Device.System.clipboard: ' + system_1.default.clipboard);
        console.log('Device.System.language: ' + system_1.default.language);
        console.log('Device.System.region: ' + system_1.default.region);
        console.log('Device.System.vibrate(): ' + system_1.default.vibrate({ millisecond: 500 }));
        console.log('Device.System.fingerPrintAvailable: ' + system_1.default.fingerPrintAvailable);
        console.log('Device.System.isEmulator: ' + system_1.default.isEmulator);
        console.log('Device.System.biometricsAvailable: ' + system_1.default.biometricsAvailable);
        console.log('Device.System.biometricType: ' + system_1.default.biometricType);
        if (system_1.default.OS === system_1.default.OSType.ANDROID) {
            console.log('Device.System.android.apiLevel: ' + system_1.default.android.apiLevel);
            console.log('Device.System.android.menuKeyAvaliable: ' + system_1.default.android.menuKeyAvaliable);
        }
        this.lblSystemDetails.text = "\n    System.OS: ".concat(system_1.default.OS, "\n    System.OSVersion: ").concat(system_1.default.OSVersion, "\n    System.batteryLevel: ").concat(system_1.default.batteryLevel, "\n    System.isBatteryCharged: ").concat(system_1.default.isBatteryCharged, "\n    System.clipboard: ").concat(system_1.default.clipboard, "\n    System.language: ").concat(system_1.default.language, "\n    System.region: ").concat(system_1.default.region, "\n    System.vibrate(): ").concat(system_1.default.vibrate({ millisecond: 500 }), "\n    System.fingerPrintAvailable: ").concat(system_1.default.fingerPrintAvailable, "\n    System.isEmulator: ").concat(system_1.default.isEmulator, "\n    System.biometricsAvailable: ").concat(system_1.default.biometricsAvailable, "\n    System.biometricType: ").concat(system_1.default.biometricType, "\n    System.android.apiLevel: ").concat(system_1.default.OS === system_1.default.OSType.ANDROID ? system_1.default.android.apiLevel : 'NOT AND', "\n    System.android.menuKeyAvailable: ").concat(system_1.default.OS === system_1.default.OSType.ANDROID ? system_1.default.android.menuKeyAvaliable : 'NOT AND');
    };
    PgSystem.prototype.onShow = function () {
        _super.prototype.onShow.call(this);
        this.printSystem();
        this.initBackButton(this.router); //Addes a back button to the page headerbar.
    };
    /**
     * @event onLoad
     * This event is called once when the page is created.
     */
    PgSystem.prototype.onLoad = function () {
        _super.prototype.onLoad.call(this);
    };
    return PgSystem;
}((0, mixins_1.withDismissAndBackButton)(pgSystem_1.default)));
exports.default = PgSystem;
//# sourceMappingURL=pgSystem.js.map