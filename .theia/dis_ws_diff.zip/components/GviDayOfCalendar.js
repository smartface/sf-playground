"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var color_1 = __importDefault(require("@smartface/native/ui/color"));
var GviDayOfCalendar_1 = __importDefault(require("generated/my-components/GviDayOfCalendar"));
var GviDayOfCalendar = /** @class */ (function (_super) {
    __extends(GviDayOfCalendar, _super);
    function GviDayOfCalendar(props, pageName) {
        var _this = 
        // Initalizes super class for this scope
        _super.call(this, props) || this;
        _this.pageName = pageName;
        _this.btnDay0.on('press', function () {
            _this === null || _this === void 0 ? void 0 : _this._day0Click();
        });
        _this.btnDay1.on('press', function () {
            _this === null || _this === void 0 ? void 0 : _this._day1Click();
        });
        _this.btnDay2.on('press', function () {
            _this === null || _this === void 0 ? void 0 : _this._day2Click();
        });
        _this.btnDay3.on('press', function () {
            _this === null || _this === void 0 ? void 0 : _this._day3Click();
        });
        _this.btnDay4.on('press', function () {
            _this === null || _this === void 0 ? void 0 : _this._day4Click();
        });
        _this.btnDay5.on('press', function () {
            _this === null || _this === void 0 ? void 0 : _this._day5Click();
        });
        _this.btnDay6.on('press', function () {
            _this === null || _this === void 0 ? void 0 : _this._day6Click();
        });
        return _this;
    }
    Object.defineProperty(GviDayOfCalendar.prototype, "days", {
        get: function () {
            return this._days;
        },
        set: function (value) {
            this._days = value;
            this.initDayButton();
        },
        enumerable: false,
        configurable: true
    });
    GviDayOfCalendar.prototype.initDayButton = function () {
        var _this = this;
        this._days.forEach(function (day, index) {
            if (day.isWeekend) {
                _this["btnDay".concat(index)].textColor = color_1.default.GRAY;
            }
            if (day.today) {
                _this["btnDay".concat(index)].textColor = color_1.default.RED;
            }
            else {
                _this["btnDay".concat(index)].textColor = color_1.default.BLACK;
            }
            _this["btnDay".concat(index)].text = day.day;
            _this["btnDay".concat(index)].backgroundColor = color_1.default.WHITE;
        });
    };
    Object.defineProperty(GviDayOfCalendar.prototype, "onDay0Click", {
        get: function () {
            return this._day0Click;
        },
        set: function (value) {
            this._day0Click = value;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(GviDayOfCalendar.prototype, "onDay1Click", {
        get: function () {
            return this._day1Click;
        },
        set: function (value) {
            this._day1Click = value;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(GviDayOfCalendar.prototype, "onDay2Click", {
        get: function () {
            return this._day2Click;
        },
        set: function (value) {
            this._day2Click = value;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(GviDayOfCalendar.prototype, "onDay3Click", {
        get: function () {
            return this._day3Click;
        },
        set: function (value) {
            this._day3Click = value;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(GviDayOfCalendar.prototype, "onDay4Click", {
        get: function () {
            return this._day4Click;
        },
        set: function (value) {
            this._day4Click = value;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(GviDayOfCalendar.prototype, "onDay5Click", {
        get: function () {
            return this._day5Click;
        },
        set: function (value) {
            this._day5Click = value;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(GviDayOfCalendar.prototype, "onDay6Click", {
        get: function () {
            return this._day6Click;
        },
        set: function (value) {
            this._day6Click = value;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(GviDayOfCalendar.prototype, "selectedDay", {
        get: function () {
            return this._selectedDay;
        },
        set: function (value) {
            this.initDayButton();
            this._selectedDay = value;
            var selectedIndex = this.findSelectedDayByIndex(value);
            this["btnDay".concat(selectedIndex)].textColor = color_1.default.WHITE;
            this["btnDay".concat(selectedIndex)].backgroundColor = color_1.default.BLACK;
        },
        enumerable: false,
        configurable: true
    });
    GviDayOfCalendar.prototype.findSelectedDayByIndex = function (value) {
        console.log(value, ' value');
        var selectedIndex;
        this._days.forEach(function (day, index) {
            if (day.day == value.day) {
                selectedIndex = index;
            }
        });
        return selectedIndex;
    };
    return GviDayOfCalendar;
}(GviDayOfCalendar_1.default));
exports.default = GviDayOfCalendar;
//# sourceMappingURL=GviDayOfCalendar.js.map