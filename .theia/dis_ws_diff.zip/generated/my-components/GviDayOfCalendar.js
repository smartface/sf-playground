"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var styling_context_1 = require("@smartface/styling-context");
var gridviewitem_1 = __importDefault(require("@smartface/native/ui/gridviewitem"));
var button_1 = __importDefault(require("@smartface/native/ui/button"));
var $GviDayOfCalendar = /** @class */ (function (_super) {
    __extends($GviDayOfCalendar, _super);
    function $GviDayOfCalendar(props) {
        var _this = _super.call(this, props) || this;
        _this._children = {};
        _this.addChildByName(new $GviDayOfCalendar$$BtnDay0(), 'btnDay0');
        _this.addChildByName(new $GviDayOfCalendar$$BtnDay1(), 'btnDay1');
        _this.addChildByName(new $GviDayOfCalendar$$BtnDay2(), 'btnDay2');
        _this.addChildByName(new $GviDayOfCalendar$$BtnDay3(), 'btnDay3');
        _this.addChildByName(new $GviDayOfCalendar$$BtnDay4(), 'btnDay4');
        _this.addChildByName(new $GviDayOfCalendar$$BtnDay5(), 'btnDay5');
        _this.addChildByName(new $GviDayOfCalendar$$BtnDay6(), 'btnDay6');
        _this.btnDay0 = _this.children.btnDay0;
        _this.btnDay1 = _this.children.btnDay1;
        _this.btnDay2 = _this.children.btnDay2;
        _this.btnDay3 = _this.children.btnDay3;
        _this.btnDay4 = _this.children.btnDay4;
        _this.btnDay5 = _this.children.btnDay5;
        _this.btnDay6 = _this.children.btnDay6;
        _this.testId = '___library___GviDayOfCalendar';
        return _this;
    }
    Object.defineProperty($GviDayOfCalendar.prototype, "children", {
        get: function () {
            return this._children;
        },
        enumerable: false,
        configurable: true
    });
    /**
     * @deprecated The method should not be used
     */
    $GviDayOfCalendar.prototype.addChildByName = function (child, name) {
        this._children[name] = child;
        this.addStyleableChild(child, name);
        this.addChild(child);
    };
    $GviDayOfCalendar.prototype.addChild = function (child, name, classNames, userProps, defaultClassNames) {
        if (this['layout']) {
            this['layout'].addChild(child);
        }
        else {
            _super.prototype.addChild.call(this, child);
        }
        if (name) {
            this.addStyleableChild(child, name, classNames, userProps, defaultClassNames);
        }
    };
    $GviDayOfCalendar.prototype.applyTestIDs = function (testId) {
        var _this = this;
        Object.keys(this._children).forEach(function (child) {
            _this._children[child].testId = testId + '_' + child.charAt(0).toUpperCase() + child.slice(1);
            if (_this._children[child].applyTestIDs) {
                _this._children[child].applyTestIDs(_this._children[child].testId);
            }
        });
    };
    $GviDayOfCalendar.$$styleContext = {
        classNames: '.sf-gridViewItem .gviDayOfCalendar',
        defaultClassNames: '.default_common .default_gridViewItem',
        userProps: {}
    };
    return $GviDayOfCalendar;
}((0, styling_context_1.styleableContainerComponentMixin)(gridviewitem_1.default)));
exports.default = $GviDayOfCalendar;
var $GviDayOfCalendar$$BtnDay0 = /** @class */ (function (_super) {
    __extends($GviDayOfCalendar$$BtnDay0, _super);
    function $GviDayOfCalendar$$BtnDay0(props) {
        var _this = _super.call(this, { text: '0' }) || this;
        _this.testId = '___library___GviDayOfCalendar_BtnDay0';
        return _this;
    }
    $GviDayOfCalendar$$BtnDay0.$$styleContext = {
        classNames: '.sf-button .btnDay',
        defaultClassNames: '.default_common .default_button',
        userProps: {}
    };
    return $GviDayOfCalendar$$BtnDay0;
}((0, styling_context_1.styleableComponentMixin)(button_1.default)));
var $GviDayOfCalendar$$BtnDay1 = /** @class */ (function (_super) {
    __extends($GviDayOfCalendar$$BtnDay1, _super);
    function $GviDayOfCalendar$$BtnDay1(props) {
        var _this = _super.call(this, { text: '1' }) || this;
        _this.testId = '___library___GviDayOfCalendar_BtnDay1';
        return _this;
    }
    $GviDayOfCalendar$$BtnDay1.$$styleContext = {
        classNames: '.sf-button .btnDay',
        defaultClassNames: '.default_common .default_button',
        userProps: {}
    };
    return $GviDayOfCalendar$$BtnDay1;
}((0, styling_context_1.styleableComponentMixin)(button_1.default)));
var $GviDayOfCalendar$$BtnDay2 = /** @class */ (function (_super) {
    __extends($GviDayOfCalendar$$BtnDay2, _super);
    function $GviDayOfCalendar$$BtnDay2(props) {
        var _this = _super.call(this, { text: '2' }) || this;
        _this.testId = '___library___GviDayOfCalendar_BtnDay2';
        return _this;
    }
    $GviDayOfCalendar$$BtnDay2.$$styleContext = {
        classNames: '.sf-button .btnDay',
        defaultClassNames: '.default_common .default_button',
        userProps: {}
    };
    return $GviDayOfCalendar$$BtnDay2;
}((0, styling_context_1.styleableComponentMixin)(button_1.default)));
var $GviDayOfCalendar$$BtnDay3 = /** @class */ (function (_super) {
    __extends($GviDayOfCalendar$$BtnDay3, _super);
    function $GviDayOfCalendar$$BtnDay3(props) {
        var _this = _super.call(this, { text: '3' }) || this;
        _this.testId = '___library___GviDayOfCalendar_BtnDay3';
        return _this;
    }
    $GviDayOfCalendar$$BtnDay3.$$styleContext = {
        classNames: '.sf-button .btnDay',
        defaultClassNames: '.default_common .default_button',
        userProps: {}
    };
    return $GviDayOfCalendar$$BtnDay3;
}((0, styling_context_1.styleableComponentMixin)(button_1.default)));
var $GviDayOfCalendar$$BtnDay4 = /** @class */ (function (_super) {
    __extends($GviDayOfCalendar$$BtnDay4, _super);
    function $GviDayOfCalendar$$BtnDay4(props) {
        var _this = _super.call(this, { text: '4' }) || this;
        _this.testId = '___library___GviDayOfCalendar_BtnDay4';
        return _this;
    }
    $GviDayOfCalendar$$BtnDay4.$$styleContext = {
        classNames: '.sf-button .btnDay',
        defaultClassNames: '.default_common .default_button',
        userProps: {}
    };
    return $GviDayOfCalendar$$BtnDay4;
}((0, styling_context_1.styleableComponentMixin)(button_1.default)));
var $GviDayOfCalendar$$BtnDay5 = /** @class */ (function (_super) {
    __extends($GviDayOfCalendar$$BtnDay5, _super);
    function $GviDayOfCalendar$$BtnDay5(props) {
        var _this = _super.call(this, { text: '5' }) || this;
        _this.testId = '___library___GviDayOfCalendar_BtnDay5';
        return _this;
    }
    $GviDayOfCalendar$$BtnDay5.$$styleContext = {
        classNames: '.sf-button .btnDay',
        defaultClassNames: '.default_common .default_button',
        userProps: {}
    };
    return $GviDayOfCalendar$$BtnDay5;
}((0, styling_context_1.styleableComponentMixin)(button_1.default)));
var $GviDayOfCalendar$$BtnDay6 = /** @class */ (function (_super) {
    __extends($GviDayOfCalendar$$BtnDay6, _super);
    function $GviDayOfCalendar$$BtnDay6(props) {
        var _this = _super.call(this, { text: '6' }) || this;
        _this.testId = '___library___GviDayOfCalendar_BtnDay6';
        return _this;
    }
    $GviDayOfCalendar$$BtnDay6.$$styleContext = {
        classNames: '.sf-button .btnDay',
        defaultClassNames: '.default_common .default_button',
        userProps: {}
    };
    return $GviDayOfCalendar$$BtnDay6;
}((0, styling_context_1.styleableComponentMixin)(button_1.default)));
//# sourceMappingURL=GviDayOfCalendar.js.map