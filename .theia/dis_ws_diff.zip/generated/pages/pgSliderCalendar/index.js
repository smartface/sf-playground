"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
//------------------------------------------------------------------------------
//
//     This code was auto generated.
//
//     Manual changes to this file may cause unexpected behavior in your application.
//     Manual changes to this file will be overwritten if the code is regenerated.
//
//------------------------------------------------------------------------------
var styling_context_1 = require("@smartface/styling-context");
var page_1 = __importDefault(require("@smartface/native/ui/page"));
var flexlayout_1 = __importDefault(require("@smartface/native/ui/flexlayout"));
var label_1 = __importDefault(require("@smartface/native/ui/label"));
var gridview_1 = __importDefault(require("@smartface/native/ui/gridview"));
var layoutmanager_1 = __importDefault(require("@smartface/native/ui/layoutmanager"));
var addChild_1 = __importDefault(require("@smartface/styling-context/lib/action/addChild"));
var GviDayOfCalendar_1 = __importDefault(require("components/GviDayOfCalendar"));
var $PgSliderCalendar = /** @class */ (function (_super) {
    __extends($PgSliderCalendar, _super);
    function $PgSliderCalendar(props) {
        var _this = _super.call(this, Object.assign({}, props)) || this;
        _this._children = {};
        _this._children.statusBar = _this.statusBar || {};
        _this._children.headerBar = _this.headerBar || {};
        _this.addChildByName(new $FlCalendarWrapper(), 'flCalendarWrapper');
        _this.addChildByName(new $LblFullDate(), 'lblFullDate');
        _this.flCalendarWrapper = _this.children.flCalendarWrapper;
        _this.flDaysName = _this.children.flCalendarWrapper.children.flDaysName;
        _this.day0lbl = _this.children.flCalendarWrapper.children.flDaysName.children.day0lbl;
        _this.day1lbl = _this.children.flCalendarWrapper.children.flDaysName.children.day1lbl;
        _this.day2lbl = _this.children.flCalendarWrapper.children.flDaysName.children.day2lbl;
        _this.day3lbl = _this.children.flCalendarWrapper.children.flDaysName.children.day3lbl;
        _this.day4lbl = _this.children.flCalendarWrapper.children.flDaysName.children.day4lbl;
        _this.day5lbl = _this.children.flCalendarWrapper.children.flDaysName.children.day5lbl;
        _this.day6lbl = _this.children.flCalendarWrapper.children.flDaysName.children.day6lbl;
        _this.gvMain = _this.children.flCalendarWrapper.children.gvMain;
        _this.lblFullDate = _this.children.lblFullDate;
        _this.applyTestIDs('_PgSliderCalendar');
        return _this;
    }
    Object.defineProperty($PgSliderCalendar.prototype, "children", {
        get: function () {
            return this._children;
        },
        enumerable: false,
        configurable: true
    });
    $PgSliderCalendar.prototype.getName = function () {
        return 'PgSliderCalendar';
    };
    $PgSliderCalendar.prototype.onLoad = function () {
        _super.prototype.onLoad.call(this);
        this.headerBar.title = 'pgSliderCalendar';
    };
    $PgSliderCalendar.prototype.addChild = function (child, name, classNames, userProps, defaultClassNames) {
        if (this['layout']) {
            this['layout'].addChild(child);
        }
        if (name) {
            this.addStyleableChild(child, name, classNames, userProps, defaultClassNames);
        }
    };
    /**
     * @deprecated The method should not be used
     */
    $PgSliderCalendar.prototype.addChildByName = function (child, name) {
        this._children[name] = child;
        this.addStyleableChild(child, name);
        this.addChild(child);
    };
    $PgSliderCalendar.prototype.applyTestIDs = function (testId) {
        var _this = this;
        Object.keys(this._children).forEach(function (child) {
            _this._children[child].testId = testId + '_' + child.charAt(0).toUpperCase() + child.slice(1);
            if (_this._children[child].applyTestIDs) {
                _this._children[child].applyTestIDs(_this._children[child].testId);
            }
        });
    };
    $PgSliderCalendar.prototype.removeChild = function (child) {
        var _this = this;
        _super.prototype.removeChild.call(this, child);
        Object.keys(this._children).forEach(function (name) {
            if (child === _this._children[name])
                delete _this._children[name];
        });
    };
    $PgSliderCalendar.prototype.removeChildren = function () {
        this._children = { statusBar: this._children.statusBar, headerBar: this._children.headerBar };
        _super.prototype.removeChildren.call(this);
    };
    $PgSliderCalendar.$$styleContext = {
        classNames: '.sf-page',
        defaultClassNames: ' .default_page',
        userProps: {},
        statusBar: {
            classNames: '.sf-statusBar',
            defaultClassNames: ' .default_statusBar',
            userProps: {}
        },
        headerBar: {
            classNames: '.sf-headerBar',
            defaultClassNames: ' .default_headerBar',
            userProps: {}
        }
    };
    return $PgSliderCalendar;
}((0, styling_context_1.styleablePageMixin)(page_1.default)));
exports.default = $PgSliderCalendar;
var $FlCalendarWrapper = /** @class */ (function (_super) {
    __extends($FlCalendarWrapper, _super);
    function $FlCalendarWrapper(props) {
        var _this = _super.call(this, props) || this;
        _this._children = {};
        _this.addChildByName(new $FlCalendarWrapper$$FlDaysName(), 'flDaysName');
        _this.addChildByName(new $FlCalendarWrapper$$GvMain(), 'gvMain');
        return _this;
    }
    Object.defineProperty($FlCalendarWrapper.prototype, "children", {
        get: function () {
            return this._children;
        },
        enumerable: false,
        configurable: true
    });
    /**
     * @deprecated The method should not be used
     */
    $FlCalendarWrapper.prototype.addChildByName = function (child, name) {
        this._children[name] = child;
        if (this['layout']) {
            this['layout'].addChild(child);
        }
        else {
            this.addChild(child);
        }
    };
    $FlCalendarWrapper.prototype.applyTestIDs = function (testId) {
        var _this = this;
        Object.keys(this._children).forEach(function (child) {
            _this._children[child].testId = testId + '_' + child.charAt(0).toUpperCase() + child.slice(1);
            if (_this._children[child].applyTestIDs) {
                _this._children[child].applyTestIDs(_this._children[child].testId);
            }
        });
    };
    $FlCalendarWrapper.$$styleContext = {
        classNames: '.sf-flexLayout',
        defaultClassNames: '.default_common .default_flexLayout',
        userProps: {}
    };
    return $FlCalendarWrapper;
}((0, styling_context_1.styleableContainerComponentMixin)(flexlayout_1.default)));
var $FlCalendarWrapper$$FlDaysName = /** @class */ (function (_super) {
    __extends($FlCalendarWrapper$$FlDaysName, _super);
    function $FlCalendarWrapper$$FlDaysName(props) {
        var _this = _super.call(this, props) || this;
        _this._children = {};
        _this.addChildByName(new $FlCalendarWrapper$$FlDaysName$$Day0lbl(), 'day0lbl');
        _this.addChildByName(new $FlCalendarWrapper$$FlDaysName$$Day1lbl(), 'day1lbl');
        _this.addChildByName(new $FlCalendarWrapper$$FlDaysName$$Day2lbl(), 'day2lbl');
        _this.addChildByName(new $FlCalendarWrapper$$FlDaysName$$Day3lbl(), 'day3lbl');
        _this.addChildByName(new $FlCalendarWrapper$$FlDaysName$$Day4lbl(), 'day4lbl');
        _this.addChildByName(new $FlCalendarWrapper$$FlDaysName$$Day5lbl(), 'day5lbl');
        _this.addChildByName(new $FlCalendarWrapper$$FlDaysName$$Day6lbl(), 'day6lbl');
        return _this;
    }
    Object.defineProperty($FlCalendarWrapper$$FlDaysName.prototype, "children", {
        get: function () {
            return this._children;
        },
        enumerable: false,
        configurable: true
    });
    /**
     * @deprecated The method should not be used
     */
    $FlCalendarWrapper$$FlDaysName.prototype.addChildByName = function (child, name) {
        this._children[name] = child;
        if (this['layout']) {
            this['layout'].addChild(child);
        }
        else {
            this.addChild(child);
        }
    };
    $FlCalendarWrapper$$FlDaysName.prototype.applyTestIDs = function (testId) {
        var _this = this;
        Object.keys(this._children).forEach(function (child) {
            _this._children[child].testId = testId + '_' + child.charAt(0).toUpperCase() + child.slice(1);
            if (_this._children[child].applyTestIDs) {
                _this._children[child].applyTestIDs(_this._children[child].testId);
            }
        });
    };
    $FlCalendarWrapper$$FlDaysName.$$styleContext = {
        classNames: '.sf-flexLayout #pgSliderCalendar-flDaysName',
        defaultClassNames: '.default_common .default_flexLayout',
        userProps: {}
    };
    return $FlCalendarWrapper$$FlDaysName;
}((0, styling_context_1.styleableContainerComponentMixin)(flexlayout_1.default)));
var $FlCalendarWrapper$$FlDaysName$$Day0lbl = /** @class */ (function (_super) {
    __extends($FlCalendarWrapper$$FlDaysName$$Day0lbl, _super);
    function $FlCalendarWrapper$$FlDaysName$$Day0lbl(props) {
        return _super.call(this, { text: 'label1' }) || this;
    }
    $FlCalendarWrapper$$FlDaysName$$Day0lbl.$$styleContext = {
        classNames: '.sf-label .daylbl',
        defaultClassNames: '.default_common .default_label',
        userProps: {}
    };
    return $FlCalendarWrapper$$FlDaysName$$Day0lbl;
}((0, styling_context_1.styleableComponentMixin)(label_1.default)));
var $FlCalendarWrapper$$FlDaysName$$Day1lbl = /** @class */ (function (_super) {
    __extends($FlCalendarWrapper$$FlDaysName$$Day1lbl, _super);
    function $FlCalendarWrapper$$FlDaysName$$Day1lbl(props) {
        return _super.call(this, { text: 'label1' }) || this;
    }
    $FlCalendarWrapper$$FlDaysName$$Day1lbl.$$styleContext = {
        classNames: '.sf-label .daylbl',
        defaultClassNames: '.default_common .default_label',
        userProps: {}
    };
    return $FlCalendarWrapper$$FlDaysName$$Day1lbl;
}((0, styling_context_1.styleableComponentMixin)(label_1.default)));
var $FlCalendarWrapper$$FlDaysName$$Day2lbl = /** @class */ (function (_super) {
    __extends($FlCalendarWrapper$$FlDaysName$$Day2lbl, _super);
    function $FlCalendarWrapper$$FlDaysName$$Day2lbl(props) {
        return _super.call(this, { text: 'label1' }) || this;
    }
    $FlCalendarWrapper$$FlDaysName$$Day2lbl.$$styleContext = {
        classNames: '.sf-label .daylbl',
        defaultClassNames: '.default_common .default_label',
        userProps: {}
    };
    return $FlCalendarWrapper$$FlDaysName$$Day2lbl;
}((0, styling_context_1.styleableComponentMixin)(label_1.default)));
var $FlCalendarWrapper$$FlDaysName$$Day3lbl = /** @class */ (function (_super) {
    __extends($FlCalendarWrapper$$FlDaysName$$Day3lbl, _super);
    function $FlCalendarWrapper$$FlDaysName$$Day3lbl(props) {
        return _super.call(this, { text: 'label1' }) || this;
    }
    $FlCalendarWrapper$$FlDaysName$$Day3lbl.$$styleContext = {
        classNames: '.sf-label .daylbl',
        defaultClassNames: '.default_common .default_label',
        userProps: {}
    };
    return $FlCalendarWrapper$$FlDaysName$$Day3lbl;
}((0, styling_context_1.styleableComponentMixin)(label_1.default)));
var $FlCalendarWrapper$$FlDaysName$$Day4lbl = /** @class */ (function (_super) {
    __extends($FlCalendarWrapper$$FlDaysName$$Day4lbl, _super);
    function $FlCalendarWrapper$$FlDaysName$$Day4lbl(props) {
        return _super.call(this, { text: 'label1' }) || this;
    }
    $FlCalendarWrapper$$FlDaysName$$Day4lbl.$$styleContext = {
        classNames: '.sf-label .daylbl',
        defaultClassNames: '.default_common .default_label',
        userProps: {}
    };
    return $FlCalendarWrapper$$FlDaysName$$Day4lbl;
}((0, styling_context_1.styleableComponentMixin)(label_1.default)));
var $FlCalendarWrapper$$FlDaysName$$Day5lbl = /** @class */ (function (_super) {
    __extends($FlCalendarWrapper$$FlDaysName$$Day5lbl, _super);
    function $FlCalendarWrapper$$FlDaysName$$Day5lbl(props) {
        return _super.call(this, { text: 'label1' }) || this;
    }
    $FlCalendarWrapper$$FlDaysName$$Day5lbl.$$styleContext = {
        classNames: '.sf-label .daylbl',
        defaultClassNames: '.default_common .default_label',
        userProps: {}
    };
    return $FlCalendarWrapper$$FlDaysName$$Day5lbl;
}((0, styling_context_1.styleableComponentMixin)(label_1.default)));
var $FlCalendarWrapper$$FlDaysName$$Day6lbl = /** @class */ (function (_super) {
    __extends($FlCalendarWrapper$$FlDaysName$$Day6lbl, _super);
    function $FlCalendarWrapper$$FlDaysName$$Day6lbl(props) {
        return _super.call(this, { text: 'label1' }) || this;
    }
    $FlCalendarWrapper$$FlDaysName$$Day6lbl.$$styleContext = {
        classNames: '.sf-label .daylbl',
        defaultClassNames: '.default_common .default_label',
        userProps: {}
    };
    return $FlCalendarWrapper$$FlDaysName$$Day6lbl;
}((0, styling_context_1.styleableComponentMixin)(label_1.default)));
var $FlCalendarWrapper$$GvMain = /** @class */ (function (_super) {
    __extends($FlCalendarWrapper$$GvMain, _super);
    function $FlCalendarWrapper$$GvMain(props) {
        var _this = _super.call(this, __assign({ layoutManager: new layoutmanager_1.default({ scrollDirection: layoutmanager_1.default.ScrollDirection.HORIZONTAL, spanCount: 1, onItemLength: function () { return 227; } }) }, { itemCount: 1, itemLength: 227 })) || this;
        _this.itemIndex = 0;
        _this.onItemCreate = function () {
            var item = new $FlCalendarWrapper$$GvMain$$GviDayOfCalendar();
            _this.dispatch((0, addChild_1.default)("item".concat(++_this.itemIndex), item));
            return item;
        };
        return _this;
    }
    $FlCalendarWrapper$$GvMain.$$styleContext = {
        classNames: '.sf-gridView #pgSliderCalendar-gvMain',
        defaultClassNames: '.default_common .default_gridView',
        userProps: { props: { layoutManager: { scrollDirection: 'HORIZONTAL', spanCount: 1 } } }
    };
    return $FlCalendarWrapper$$GvMain;
}((0, styling_context_1.styleableComponentMixin)(gridview_1.default)));
var $FlCalendarWrapper$$GvMain$$GviDayOfCalendar = /** @class */ (function (_super) {
    __extends($FlCalendarWrapper$$GvMain$$GviDayOfCalendar, _super);
    function $FlCalendarWrapper$$GvMain$$GviDayOfCalendar(props) {
        return _super.call(this, props) || this;
    }
    $FlCalendarWrapper$$GvMain$$GviDayOfCalendar.$$styleContext = {
        classNames: '.sf-gridViewItem .gviDayOfCalendar #pgSliderCalendar-gviDayOfCalendar',
        defaultClassNames: '.default_common .default_gridViewItem',
        userProps: { flexProps: { positionType: 'RELATIVE' } }
    };
    return $FlCalendarWrapper$$GvMain$$GviDayOfCalendar;
}(GviDayOfCalendar_1.default));
var $LblFullDate = /** @class */ (function (_super) {
    __extends($LblFullDate, _super);
    function $LblFullDate(props) {
        return _super.call(this, { text: 'label1' }) || this;
    }
    $LblFullDate.$$styleContext = {
        classNames: '.sf-label #pgSliderCalendar-lblFullDate',
        defaultClassNames: '.default_common .default_label',
        userProps: {}
    };
    return $LblFullDate;
}((0, styling_context_1.styleableComponentMixin)(label_1.default)));
//# sourceMappingURL=index.js.map