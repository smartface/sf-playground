"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
//------------------------------------------------------------------------------
//
//     This code was auto generated.
//
//     Manual changes to this file may cause unexpected behavior in your application.
//     Manual changes to this file will be overwritten if the code is regenerated.
//
//------------------------------------------------------------------------------
var styling_context_1 = require("@smartface/styling-context");
var page_1 = __importDefault(require("@smartface/native/ui/page"));
var scrollview_1 = __importDefault(require("@smartface/native/ui/scrollview"));
var flexlayout_1 = __importDefault(require("@smartface/native/ui/flexlayout"));
var label_1 = __importDefault(require("@smartface/native/ui/label"));
var textbox_1 = __importDefault(require("@smartface/native/ui/textbox"));
var textarea_1 = __importDefault(require("@smartface/native/ui/textarea"));
var button_1 = __importDefault(require("@smartface/native/ui/button"));
var textview_1 = __importDefault(require("@smartface/native/ui/textview"));
var $PgColorAndHtml = /** @class */ (function (_super) {
    __extends($PgColorAndHtml, _super);
    function $PgColorAndHtml(props) {
        var _this = _super.call(this, Object.assign({}, props)) || this;
        _this._children = {};
        _this._children.statusBar = _this.statusBar || {};
        _this._children.headerBar = _this.headerBar || {};
        _this.addChildByName(new $ScrollView1(), 'scrollView1');
        _this.scrollView1 = _this.children.scrollView1;
        _this.flTouch = _this.children.scrollView1.children.flTouch;
        _this.flColorArea = _this.children.scrollView1.children.flColorArea;
        _this.lblTitle = _this.children.scrollView1.children.flColorArea.children.lblTitle;
        _this.flRow = _this.children.scrollView1.children.flColorArea.children.flRow;
        _this.lblR = _this.children.scrollView1.children.flColorArea.children.flRow.children.lblR;
        _this.tbR = _this.children.scrollView1.children.flColorArea.children.flRow.children.tbR;
        _this.lblG = _this.children.scrollView1.children.flColorArea.children.flRow.children.lblG;
        _this.tbG = _this.children.scrollView1.children.flColorArea.children.flRow.children.tbG;
        _this.lblB = _this.children.scrollView1.children.flColorArea.children.flRow.children.lblB;
        _this.tbB = _this.children.scrollView1.children.flColorArea.children.flRow.children.tbB;
        _this.flRowRgb = _this.children.scrollView1.children.flColorArea.children.flRowRgb;
        _this.lblKeyRgb = _this.children.scrollView1.children.flColorArea.children.flRowRgb.children.lblKeyRgb;
        _this.lblValueRgb = _this.children.scrollView1.children.flColorArea.children.flRowRgb.children.lblValueRgb;
        _this.flRowRgba = _this.children.scrollView1.children.flColorArea.children.flRowRgba;
        _this.lblKeyRgba = _this.children.scrollView1.children.flColorArea.children.flRowRgba.children.lblKeyRgba;
        _this.lblValueRgba = _this.children.scrollView1.children.flColorArea.children.flRowRgba.children.lblValueRgba;
        _this.flRowArgb = _this.children.scrollView1.children.flColorArea.children.flRowArgb;
        _this.lblKeyArgb = _this.children.scrollView1.children.flColorArea.children.flRowArgb.children.lblKeyArgb;
        _this.lblValueArgb = _this.children.scrollView1.children.flColorArea.children.flRowArgb.children.lblValueArgb;
        _this.flRowTinyColor = _this.children.scrollView1.children.flColorArea.children.flRowTinyColor;
        _this.lblKeyTinyColor = _this.children.scrollView1.children.flColorArea.children.flRowTinyColor.children.lblKeyTinyColor;
        _this.lblValueTinyColor = _this.children.scrollView1.children.flColorArea.children.flRowTinyColor.children.lblValueTinyColor;
        _this.flGuidArea = _this.children.scrollView1.children.flGuidArea;
        _this.lblTitleGuid = _this.children.scrollView1.children.flGuidArea.children.lblTitleGuid;
        _this.lblGuid = _this.children.scrollView1.children.flGuidArea.children.lblGuid;
        _this.flHtmlArea = _this.children.scrollView1.children.flHtmlArea;
        _this.lblTitleHtml = _this.children.scrollView1.children.flHtmlArea.children.lblTitleHtml;
        _this.taHtml = _this.children.scrollView1.children.flHtmlArea.children.taHtml;
        _this.flRowHtml = _this.children.scrollView1.children.flHtmlArea.children.flRowHtml;
        _this.btnAttrTexts = _this.children.scrollView1.children.flHtmlArea.children.flRowHtml.children.btnAttrTexts;
        _this.btnAttrStr = _this.children.scrollView1.children.flHtmlArea.children.flRowHtml.children.btnAttrStr;
        _this.tvHtml = _this.children.scrollView1.children.flHtmlArea.children.tvHtml;
        _this.tvAttrString = _this.children.scrollView1.children.flHtmlArea.children.tvAttrString;
        _this.flNativeStyleArea = _this.children.scrollView1.children.flNativeStyleArea;
        _this.lblTitleGetNativeStyle = _this.children.scrollView1.children.flNativeStyleArea.children.lblTitleGetNativeStyle;
        _this.btnGetNativeStyle = _this.children.scrollView1.children.flNativeStyleArea.children.btnGetNativeStyle;
        _this.btnGradientColor = _this.children.scrollView1.children.flNativeStyleArea.children.btnGradientColor;
        _this.applyTestIDs('_PgColorAndHtml');
        return _this;
    }
    Object.defineProperty($PgColorAndHtml.prototype, "children", {
        get: function () {
            return this._children;
        },
        enumerable: false,
        configurable: true
    });
    $PgColorAndHtml.prototype.getName = function () {
        return 'PgColorAndHtml';
    };
    $PgColorAndHtml.prototype.onLoad = function () {
        _super.prototype.onLoad.call(this);
        this.headerBar.title = 'ColorAndHtml';
    };
    $PgColorAndHtml.prototype.addChild = function (child, name, classNames, userProps, defaultClassNames) {
        if (this['layout']) {
            this['layout'].addChild(child);
        }
        if (name) {
            this.addStyleableChild(child, name, classNames, userProps, defaultClassNames);
        }
    };
    /**
     * @deprecated The method should not be used
     */
    $PgColorAndHtml.prototype.addChildByName = function (child, name) {
        this._children[name] = child;
        this.addStyleableChild(child, name);
        this.addChild(child);
    };
    $PgColorAndHtml.prototype.applyTestIDs = function (testId) {
        var _this = this;
        Object.keys(this._children).forEach(function (child) {
            _this._children[child].testId = testId + '_' + child.charAt(0).toUpperCase() + child.slice(1);
            if (_this._children[child].applyTestIDs) {
                _this._children[child].applyTestIDs(_this._children[child].testId);
            }
        });
    };
    $PgColorAndHtml.prototype.removeChild = function (child) {
        var _this = this;
        _super.prototype.removeChild.call(this, child);
        Object.keys(this._children).forEach(function (name) {
            if (child === _this._children[name])
                delete _this._children[name];
        });
    };
    $PgColorAndHtml.prototype.removeChildren = function () {
        this._children = { statusBar: this._children.statusBar, headerBar: this._children.headerBar };
        _super.prototype.removeChildren.call(this);
    };
    $PgColorAndHtml.$$styleContext = {
        classNames: '.sf-page #pgColorAndHtml',
        defaultClassNames: ' .default_page',
        userProps: {},
        statusBar: {
            classNames: '.sf-statusBar',
            defaultClassNames: ' .default_statusBar',
            userProps: {}
        },
        headerBar: {
            classNames: '.sf-headerBar',
            defaultClassNames: ' .default_headerBar',
            userProps: {}
        }
    };
    return $PgColorAndHtml;
}((0, styling_context_1.styleablePageMixin)(page_1.default)));
exports.default = $PgColorAndHtml;
var $ScrollView1 = /** @class */ (function (_super) {
    __extends($ScrollView1, _super);
    function $ScrollView1(props) {
        var _this = _super.call(this, props) || this;
        _this._children = {};
        _this.addChildByName(new $ScrollView1$$FlTouch(), 'flTouch');
        _this.addChildByName(new $ScrollView1$$FlColorArea(), 'flColorArea');
        _this.addChildByName(new $ScrollView1$$FlGuidArea(), 'flGuidArea');
        _this.addChildByName(new $ScrollView1$$FlHtmlArea(), 'flHtmlArea');
        _this.addChildByName(new $ScrollView1$$FlNativeStyleArea(), 'flNativeStyleArea');
        return _this;
    }
    Object.defineProperty($ScrollView1.prototype, "children", {
        get: function () {
            return this._children;
        },
        enumerable: false,
        configurable: true
    });
    /**
     * @deprecated The method should not be used
     */
    $ScrollView1.prototype.addChildByName = function (child, name) {
        this._children[name] = child;
        if (this['layout']) {
            this['layout'].addChild(child);
        }
        else {
            this.addChild(child);
        }
    };
    $ScrollView1.prototype.applyTestIDs = function (testId) {
        var _this = this;
        Object.keys(this._children).forEach(function (child) {
            _this._children[child].testId = testId + '_' + child.charAt(0).toUpperCase() + child.slice(1);
            if (_this._children[child].applyTestIDs) {
                _this._children[child].applyTestIDs(_this._children[child].testId);
            }
        });
    };
    $ScrollView1.$$styleContext = {
        classNames: '.sf-scrollView .grow',
        defaultClassNames: '.default_common .default_scrollView',
        userProps: {}
    };
    return $ScrollView1;
}((0, styling_context_1.styleableContainerComponentMixin)(scrollview_1.default)));
var $ScrollView1$$FlTouch = /** @class */ (function (_super) {
    __extends($ScrollView1$$FlTouch, _super);
    function $ScrollView1$$FlTouch(props) {
        return _super.call(this, props) || this;
    }
    $ScrollView1$$FlTouch.$$styleContext = {
        classNames: '.sf-flexLayout #pgColorAndHtml-flTouch',
        defaultClassNames: '.default_common .default_flexLayout',
        userProps: { usePageVariable: true }
    };
    return $ScrollView1$$FlTouch;
}((0, styling_context_1.styleableContainerComponentMixin)(flexlayout_1.default)));
var $ScrollView1$$FlColorArea = /** @class */ (function (_super) {
    __extends($ScrollView1$$FlColorArea, _super);
    function $ScrollView1$$FlColorArea(props) {
        var _this = _super.call(this, props) || this;
        _this._children = {};
        _this.addChildByName(new $ScrollView1$$FlColorArea$$LblTitle(), 'lblTitle');
        _this.addChildByName(new $ScrollView1$$FlColorArea$$FlRow(), 'flRow');
        _this.addChildByName(new $ScrollView1$$FlColorArea$$FlRowRgb(), 'flRowRgb');
        _this.addChildByName(new $ScrollView1$$FlColorArea$$FlRowRgba(), 'flRowRgba');
        _this.addChildByName(new $ScrollView1$$FlColorArea$$FlRowArgb(), 'flRowArgb');
        _this.addChildByName(new $ScrollView1$$FlColorArea$$FlRowTinyColor(), 'flRowTinyColor');
        return _this;
    }
    Object.defineProperty($ScrollView1$$FlColorArea.prototype, "children", {
        get: function () {
            return this._children;
        },
        enumerable: false,
        configurable: true
    });
    /**
     * @deprecated The method should not be used
     */
    $ScrollView1$$FlColorArea.prototype.addChildByName = function (child, name) {
        this._children[name] = child;
        if (this['layout']) {
            this['layout'].addChild(child);
        }
        else {
            this.addChild(child);
        }
    };
    $ScrollView1$$FlColorArea.prototype.applyTestIDs = function (testId) {
        var _this = this;
        Object.keys(this._children).forEach(function (child) {
            _this._children[child].testId = testId + '_' + child.charAt(0).toUpperCase() + child.slice(1);
            if (_this._children[child].applyTestIDs) {
                _this._children[child].applyTestIDs(_this._children[child].testId);
            }
        });
    };
    $ScrollView1$$FlColorArea.$$styleContext = {
        classNames: '.sf-flexLayout #pgColorAndHtml-flColorArea .card',
        defaultClassNames: '.default_common .default_flexLayout',
        userProps: { height: 245, usePageVariable: true }
    };
    return $ScrollView1$$FlColorArea;
}((0, styling_context_1.styleableContainerComponentMixin)(flexlayout_1.default)));
var $ScrollView1$$FlColorArea$$LblTitle = /** @class */ (function (_super) {
    __extends($ScrollView1$$FlColorArea$$LblTitle, _super);
    function $ScrollView1$$FlColorArea$$LblTitle(props) {
        return _super.call(this, { text: 'Color Test' }) || this;
    }
    $ScrollView1$$FlColorArea$$LblTitle.$$styleContext = {
        classNames: '.sf-label #pgColorAndHtml-lblTitle',
        defaultClassNames: '.default_common .default_label',
        userProps: {}
    };
    return $ScrollView1$$FlColorArea$$LblTitle;
}((0, styling_context_1.styleableComponentMixin)(label_1.default)));
var $ScrollView1$$FlColorArea$$FlRow = /** @class */ (function (_super) {
    __extends($ScrollView1$$FlColorArea$$FlRow, _super);
    function $ScrollView1$$FlColorArea$$FlRow(props) {
        var _this = _super.call(this, props) || this;
        _this._children = {};
        _this.addChildByName(new $ScrollView1$$FlColorArea$$FlRow$$LblR(), 'lblR');
        _this.addChildByName(new $ScrollView1$$FlColorArea$$FlRow$$TbR(), 'tbR');
        _this.addChildByName(new $ScrollView1$$FlColorArea$$FlRow$$LblG(), 'lblG');
        _this.addChildByName(new $ScrollView1$$FlColorArea$$FlRow$$TbG(), 'tbG');
        _this.addChildByName(new $ScrollView1$$FlColorArea$$FlRow$$LblB(), 'lblB');
        _this.addChildByName(new $ScrollView1$$FlColorArea$$FlRow$$TbB(), 'tbB');
        return _this;
    }
    Object.defineProperty($ScrollView1$$FlColorArea$$FlRow.prototype, "children", {
        get: function () {
            return this._children;
        },
        enumerable: false,
        configurable: true
    });
    /**
     * @deprecated The method should not be used
     */
    $ScrollView1$$FlColorArea$$FlRow.prototype.addChildByName = function (child, name) {
        this._children[name] = child;
        if (this['layout']) {
            this['layout'].addChild(child);
        }
        else {
            this.addChild(child);
        }
    };
    $ScrollView1$$FlColorArea$$FlRow.prototype.applyTestIDs = function (testId) {
        var _this = this;
        Object.keys(this._children).forEach(function (child) {
            _this._children[child].testId = testId + '_' + child.charAt(0).toUpperCase() + child.slice(1);
            if (_this._children[child].applyTestIDs) {
                _this._children[child].applyTestIDs(_this._children[child].testId);
            }
        });
    };
    $ScrollView1$$FlColorArea$$FlRow.$$styleContext = {
        classNames: '.sf-flexLayout #pgColorAndHtml-flRow',
        defaultClassNames: '.default_common .default_flexLayout',
        userProps: { height: 45 }
    };
    return $ScrollView1$$FlColorArea$$FlRow;
}((0, styling_context_1.styleableContainerComponentMixin)(flexlayout_1.default)));
var $ScrollView1$$FlColorArea$$FlRow$$LblR = /** @class */ (function (_super) {
    __extends($ScrollView1$$FlColorArea$$FlRow$$LblR, _super);
    function $ScrollView1$$FlColorArea$$FlRow$$LblR(props) {
        return _super.call(this, { text: 'r : ' }) || this;
    }
    $ScrollView1$$FlColorArea$$FlRow$$LblR.$$styleContext = {
        classNames: '.sf-label #pgColorAndHtml-lblRgb',
        defaultClassNames: '.default_common .default_label',
        userProps: {}
    };
    return $ScrollView1$$FlColorArea$$FlRow$$LblR;
}((0, styling_context_1.styleableComponentMixin)(label_1.default)));
var $ScrollView1$$FlColorArea$$FlRow$$TbR = /** @class */ (function (_super) {
    __extends($ScrollView1$$FlColorArea$$FlRow$$TbR, _super);
    function $ScrollView1$$FlColorArea$$FlRow$$TbR(props) {
        return _super.call(this, { text: '100' }) || this;
    }
    $ScrollView1$$FlColorArea$$FlRow$$TbR.$$styleContext = {
        classNames: '.sf-textBox #pgColorAndHtml-textBox',
        defaultClassNames: '.default_common .default_textBox',
        userProps: { usePageVariable: true }
    };
    return $ScrollView1$$FlColorArea$$FlRow$$TbR;
}((0, styling_context_1.styleableComponentMixin)(textbox_1.default)));
var $ScrollView1$$FlColorArea$$FlRow$$LblG = /** @class */ (function (_super) {
    __extends($ScrollView1$$FlColorArea$$FlRow$$LblG, _super);
    function $ScrollView1$$FlColorArea$$FlRow$$LblG(props) {
        return _super.call(this, { text: 'g : ' }) || this;
    }
    $ScrollView1$$FlColorArea$$FlRow$$LblG.$$styleContext = {
        classNames: '.sf-label #pgColorAndHtml-lblRgb',
        defaultClassNames: '.default_common .default_label',
        userProps: {}
    };
    return $ScrollView1$$FlColorArea$$FlRow$$LblG;
}((0, styling_context_1.styleableComponentMixin)(label_1.default)));
var $ScrollView1$$FlColorArea$$FlRow$$TbG = /** @class */ (function (_super) {
    __extends($ScrollView1$$FlColorArea$$FlRow$$TbG, _super);
    function $ScrollView1$$FlColorArea$$FlRow$$TbG(props) {
        return _super.call(this, { text: '100' }) || this;
    }
    $ScrollView1$$FlColorArea$$FlRow$$TbG.$$styleContext = {
        classNames: '.sf-textBox #pgColorAndHtml-textBox',
        defaultClassNames: '.default_common .default_textBox',
        userProps: { usePageVariable: true }
    };
    return $ScrollView1$$FlColorArea$$FlRow$$TbG;
}((0, styling_context_1.styleableComponentMixin)(textbox_1.default)));
var $ScrollView1$$FlColorArea$$FlRow$$LblB = /** @class */ (function (_super) {
    __extends($ScrollView1$$FlColorArea$$FlRow$$LblB, _super);
    function $ScrollView1$$FlColorArea$$FlRow$$LblB(props) {
        return _super.call(this, { text: 'b : ' }) || this;
    }
    $ScrollView1$$FlColorArea$$FlRow$$LblB.$$styleContext = {
        classNames: '.sf-label #pgColorAndHtml-lblRgb',
        defaultClassNames: '.default_common .default_label',
        userProps: {}
    };
    return $ScrollView1$$FlColorArea$$FlRow$$LblB;
}((0, styling_context_1.styleableComponentMixin)(label_1.default)));
var $ScrollView1$$FlColorArea$$FlRow$$TbB = /** @class */ (function (_super) {
    __extends($ScrollView1$$FlColorArea$$FlRow$$TbB, _super);
    function $ScrollView1$$FlColorArea$$FlRow$$TbB(props) {
        return _super.call(this, { text: '100' }) || this;
    }
    $ScrollView1$$FlColorArea$$FlRow$$TbB.$$styleContext = {
        classNames: '.sf-textBox #pgColorAndHtml-textBox',
        defaultClassNames: '.default_common .default_textBox',
        userProps: { usePageVariable: true }
    };
    return $ScrollView1$$FlColorArea$$FlRow$$TbB;
}((0, styling_context_1.styleableComponentMixin)(textbox_1.default)));
var $ScrollView1$$FlColorArea$$FlRowRgb = /** @class */ (function (_super) {
    __extends($ScrollView1$$FlColorArea$$FlRowRgb, _super);
    function $ScrollView1$$FlColorArea$$FlRowRgb(props) {
        var _this = _super.call(this, props) || this;
        _this._children = {};
        _this.addChildByName(new $ScrollView1$$FlColorArea$$FlRowRgb$$LblKeyRgb(), 'lblKeyRgb');
        _this.addChildByName(new $ScrollView1$$FlColorArea$$FlRowRgb$$LblValueRgb(), 'lblValueRgb');
        return _this;
    }
    Object.defineProperty($ScrollView1$$FlColorArea$$FlRowRgb.prototype, "children", {
        get: function () {
            return this._children;
        },
        enumerable: false,
        configurable: true
    });
    /**
     * @deprecated The method should not be used
     */
    $ScrollView1$$FlColorArea$$FlRowRgb.prototype.addChildByName = function (child, name) {
        this._children[name] = child;
        if (this['layout']) {
            this['layout'].addChild(child);
        }
        else {
            this.addChild(child);
        }
    };
    $ScrollView1$$FlColorArea$$FlRowRgb.prototype.applyTestIDs = function (testId) {
        var _this = this;
        Object.keys(this._children).forEach(function (child) {
            _this._children[child].testId = testId + '_' + child.charAt(0).toUpperCase() + child.slice(1);
            if (_this._children[child].applyTestIDs) {
                _this._children[child].applyTestIDs(_this._children[child].testId);
            }
        });
    };
    $ScrollView1$$FlColorArea$$FlRowRgb.$$styleContext = {
        classNames: '.sf-flexLayout #pgColorAndHtml-flRow',
        defaultClassNames: '.default_common .default_flexLayout',
        userProps: {}
    };
    return $ScrollView1$$FlColorArea$$FlRowRgb;
}((0, styling_context_1.styleableContainerComponentMixin)(flexlayout_1.default)));
var $ScrollView1$$FlColorArea$$FlRowRgb$$LblKeyRgb = /** @class */ (function (_super) {
    __extends($ScrollView1$$FlColorArea$$FlRowRgb$$LblKeyRgb, _super);
    function $ScrollView1$$FlColorArea$$FlRowRgb$$LblKeyRgb(props) {
        return _super.call(this, { text: 'rgb' }) || this;
    }
    $ScrollView1$$FlColorArea$$FlRowRgb$$LblKeyRgb.$$styleContext = {
        classNames: '.sf-label #pgColorAndHtml-lblKey',
        defaultClassNames: '.default_common .default_label',
        userProps: {}
    };
    return $ScrollView1$$FlColorArea$$FlRowRgb$$LblKeyRgb;
}((0, styling_context_1.styleableComponentMixin)(label_1.default)));
var $ScrollView1$$FlColorArea$$FlRowRgb$$LblValueRgb = /** @class */ (function (_super) {
    __extends($ScrollView1$$FlColorArea$$FlRowRgb$$LblValueRgb, _super);
    function $ScrollView1$$FlColorArea$$FlRowRgb$$LblValueRgb(props) {
        return _super.call(this, { text: 'label3' }) || this;
    }
    $ScrollView1$$FlColorArea$$FlRowRgb$$LblValueRgb.$$styleContext = {
        classNames: '.sf-label #pgColorAndHtml-lblValue',
        defaultClassNames: '.default_common .default_label',
        userProps: { usePageVariable: true }
    };
    return $ScrollView1$$FlColorArea$$FlRowRgb$$LblValueRgb;
}((0, styling_context_1.styleableComponentMixin)(label_1.default)));
var $ScrollView1$$FlColorArea$$FlRowRgba = /** @class */ (function (_super) {
    __extends($ScrollView1$$FlColorArea$$FlRowRgba, _super);
    function $ScrollView1$$FlColorArea$$FlRowRgba(props) {
        var _this = _super.call(this, props) || this;
        _this._children = {};
        _this.addChildByName(new $ScrollView1$$FlColorArea$$FlRowRgba$$LblKeyRgba(), 'lblKeyRgba');
        _this.addChildByName(new $ScrollView1$$FlColorArea$$FlRowRgba$$LblValueRgba(), 'lblValueRgba');
        return _this;
    }
    Object.defineProperty($ScrollView1$$FlColorArea$$FlRowRgba.prototype, "children", {
        get: function () {
            return this._children;
        },
        enumerable: false,
        configurable: true
    });
    /**
     * @deprecated The method should not be used
     */
    $ScrollView1$$FlColorArea$$FlRowRgba.prototype.addChildByName = function (child, name) {
        this._children[name] = child;
        if (this['layout']) {
            this['layout'].addChild(child);
        }
        else {
            this.addChild(child);
        }
    };
    $ScrollView1$$FlColorArea$$FlRowRgba.prototype.applyTestIDs = function (testId) {
        var _this = this;
        Object.keys(this._children).forEach(function (child) {
            _this._children[child].testId = testId + '_' + child.charAt(0).toUpperCase() + child.slice(1);
            if (_this._children[child].applyTestIDs) {
                _this._children[child].applyTestIDs(_this._children[child].testId);
            }
        });
    };
    $ScrollView1$$FlColorArea$$FlRowRgba.$$styleContext = {
        classNames: '.sf-flexLayout #pgColorAndHtml-flRow',
        defaultClassNames: '.default_common .default_flexLayout',
        userProps: {}
    };
    return $ScrollView1$$FlColorArea$$FlRowRgba;
}((0, styling_context_1.styleableContainerComponentMixin)(flexlayout_1.default)));
var $ScrollView1$$FlColorArea$$FlRowRgba$$LblKeyRgba = /** @class */ (function (_super) {
    __extends($ScrollView1$$FlColorArea$$FlRowRgba$$LblKeyRgba, _super);
    function $ScrollView1$$FlColorArea$$FlRowRgba$$LblKeyRgba(props) {
        return _super.call(this, { text: 'rgba' }) || this;
    }
    $ScrollView1$$FlColorArea$$FlRowRgba$$LblKeyRgba.$$styleContext = {
        classNames: '.sf-label #pgColorAndHtml-lblKey',
        defaultClassNames: '.default_common .default_label',
        userProps: {}
    };
    return $ScrollView1$$FlColorArea$$FlRowRgba$$LblKeyRgba;
}((0, styling_context_1.styleableComponentMixin)(label_1.default)));
var $ScrollView1$$FlColorArea$$FlRowRgba$$LblValueRgba = /** @class */ (function (_super) {
    __extends($ScrollView1$$FlColorArea$$FlRowRgba$$LblValueRgba, _super);
    function $ScrollView1$$FlColorArea$$FlRowRgba$$LblValueRgba(props) {
        return _super.call(this, { text: 'label3' }) || this;
    }
    $ScrollView1$$FlColorArea$$FlRowRgba$$LblValueRgba.$$styleContext = {
        classNames: '.sf-label #pgColorAndHtml-lblValue',
        defaultClassNames: '.default_common .default_label',
        userProps: { usePageVariable: true }
    };
    return $ScrollView1$$FlColorArea$$FlRowRgba$$LblValueRgba;
}((0, styling_context_1.styleableComponentMixin)(label_1.default)));
var $ScrollView1$$FlColorArea$$FlRowArgb = /** @class */ (function (_super) {
    __extends($ScrollView1$$FlColorArea$$FlRowArgb, _super);
    function $ScrollView1$$FlColorArea$$FlRowArgb(props) {
        var _this = _super.call(this, props) || this;
        _this._children = {};
        _this.addChildByName(new $ScrollView1$$FlColorArea$$FlRowArgb$$LblKeyArgb(), 'lblKeyArgb');
        _this.addChildByName(new $ScrollView1$$FlColorArea$$FlRowArgb$$LblValueArgb(), 'lblValueArgb');
        return _this;
    }
    Object.defineProperty($ScrollView1$$FlColorArea$$FlRowArgb.prototype, "children", {
        get: function () {
            return this._children;
        },
        enumerable: false,
        configurable: true
    });
    /**
     * @deprecated The method should not be used
     */
    $ScrollView1$$FlColorArea$$FlRowArgb.prototype.addChildByName = function (child, name) {
        this._children[name] = child;
        if (this['layout']) {
            this['layout'].addChild(child);
        }
        else {
            this.addChild(child);
        }
    };
    $ScrollView1$$FlColorArea$$FlRowArgb.prototype.applyTestIDs = function (testId) {
        var _this = this;
        Object.keys(this._children).forEach(function (child) {
            _this._children[child].testId = testId + '_' + child.charAt(0).toUpperCase() + child.slice(1);
            if (_this._children[child].applyTestIDs) {
                _this._children[child].applyTestIDs(_this._children[child].testId);
            }
        });
    };
    $ScrollView1$$FlColorArea$$FlRowArgb.$$styleContext = {
        classNames: '.sf-flexLayout #pgColorAndHtml-flRow',
        defaultClassNames: '.default_common .default_flexLayout',
        userProps: {}
    };
    return $ScrollView1$$FlColorArea$$FlRowArgb;
}((0, styling_context_1.styleableContainerComponentMixin)(flexlayout_1.default)));
var $ScrollView1$$FlColorArea$$FlRowArgb$$LblKeyArgb = /** @class */ (function (_super) {
    __extends($ScrollView1$$FlColorArea$$FlRowArgb$$LblKeyArgb, _super);
    function $ScrollView1$$FlColorArea$$FlRowArgb$$LblKeyArgb(props) {
        return _super.call(this, { text: 'argb' }) || this;
    }
    $ScrollView1$$FlColorArea$$FlRowArgb$$LblKeyArgb.$$styleContext = {
        classNames: '.sf-label #pgColorAndHtml-lblKey',
        defaultClassNames: '.default_common .default_label',
        userProps: {}
    };
    return $ScrollView1$$FlColorArea$$FlRowArgb$$LblKeyArgb;
}((0, styling_context_1.styleableComponentMixin)(label_1.default)));
var $ScrollView1$$FlColorArea$$FlRowArgb$$LblValueArgb = /** @class */ (function (_super) {
    __extends($ScrollView1$$FlColorArea$$FlRowArgb$$LblValueArgb, _super);
    function $ScrollView1$$FlColorArea$$FlRowArgb$$LblValueArgb(props) {
        return _super.call(this, { text: 'label3' }) || this;
    }
    $ScrollView1$$FlColorArea$$FlRowArgb$$LblValueArgb.$$styleContext = {
        classNames: '.sf-label #pgColorAndHtml-lblValue',
        defaultClassNames: '.default_common .default_label',
        userProps: { usePageVariable: true }
    };
    return $ScrollView1$$FlColorArea$$FlRowArgb$$LblValueArgb;
}((0, styling_context_1.styleableComponentMixin)(label_1.default)));
var $ScrollView1$$FlColorArea$$FlRowTinyColor = /** @class */ (function (_super) {
    __extends($ScrollView1$$FlColorArea$$FlRowTinyColor, _super);
    function $ScrollView1$$FlColorArea$$FlRowTinyColor(props) {
        var _this = _super.call(this, props) || this;
        _this._children = {};
        _this.addChildByName(new $ScrollView1$$FlColorArea$$FlRowTinyColor$$LblKeyTinyColor(), 'lblKeyTinyColor');
        _this.addChildByName(new $ScrollView1$$FlColorArea$$FlRowTinyColor$$LblValueTinyColor(), 'lblValueTinyColor');
        return _this;
    }
    Object.defineProperty($ScrollView1$$FlColorArea$$FlRowTinyColor.prototype, "children", {
        get: function () {
            return this._children;
        },
        enumerable: false,
        configurable: true
    });
    /**
     * @deprecated The method should not be used
     */
    $ScrollView1$$FlColorArea$$FlRowTinyColor.prototype.addChildByName = function (child, name) {
        this._children[name] = child;
        if (this['layout']) {
            this['layout'].addChild(child);
        }
        else {
            this.addChild(child);
        }
    };
    $ScrollView1$$FlColorArea$$FlRowTinyColor.prototype.applyTestIDs = function (testId) {
        var _this = this;
        Object.keys(this._children).forEach(function (child) {
            _this._children[child].testId = testId + '_' + child.charAt(0).toUpperCase() + child.slice(1);
            if (_this._children[child].applyTestIDs) {
                _this._children[child].applyTestIDs(_this._children[child].testId);
            }
        });
    };
    $ScrollView1$$FlColorArea$$FlRowTinyColor.$$styleContext = {
        classNames: '.sf-flexLayout #pgColorAndHtml-flRow',
        defaultClassNames: '.default_common .default_flexLayout',
        userProps: {}
    };
    return $ScrollView1$$FlColorArea$$FlRowTinyColor;
}((0, styling_context_1.styleableContainerComponentMixin)(flexlayout_1.default)));
var $ScrollView1$$FlColorArea$$FlRowTinyColor$$LblKeyTinyColor = /** @class */ (function (_super) {
    __extends($ScrollView1$$FlColorArea$$FlRowTinyColor$$LblKeyTinyColor, _super);
    function $ScrollView1$$FlColorArea$$FlRowTinyColor$$LblKeyTinyColor(props) {
        return _super.call(this, { text: 'tinycolor' }) || this;
    }
    $ScrollView1$$FlColorArea$$FlRowTinyColor$$LblKeyTinyColor.$$styleContext = {
        classNames: '.sf-label #pgColorAndHtml-lblKey',
        defaultClassNames: '.default_common .default_label',
        userProps: {}
    };
    return $ScrollView1$$FlColorArea$$FlRowTinyColor$$LblKeyTinyColor;
}((0, styling_context_1.styleableComponentMixin)(label_1.default)));
var $ScrollView1$$FlColorArea$$FlRowTinyColor$$LblValueTinyColor = /** @class */ (function (_super) {
    __extends($ScrollView1$$FlColorArea$$FlRowTinyColor$$LblValueTinyColor, _super);
    function $ScrollView1$$FlColorArea$$FlRowTinyColor$$LblValueTinyColor(props) {
        return _super.call(this, { text: 'label3' }) || this;
    }
    $ScrollView1$$FlColorArea$$FlRowTinyColor$$LblValueTinyColor.$$styleContext = {
        classNames: '.sf-label #pgColorAndHtml-lblValue',
        defaultClassNames: '.default_common .default_label',
        userProps: { usePageVariable: true }
    };
    return $ScrollView1$$FlColorArea$$FlRowTinyColor$$LblValueTinyColor;
}((0, styling_context_1.styleableComponentMixin)(label_1.default)));
var $ScrollView1$$FlGuidArea = /** @class */ (function (_super) {
    __extends($ScrollView1$$FlGuidArea, _super);
    function $ScrollView1$$FlGuidArea(props) {
        var _this = _super.call(this, props) || this;
        _this._children = {};
        _this.addChildByName(new $ScrollView1$$FlGuidArea$$LblTitleGuid(), 'lblTitleGuid');
        _this.addChildByName(new $ScrollView1$$FlGuidArea$$LblGuid(), 'lblGuid');
        return _this;
    }
    Object.defineProperty($ScrollView1$$FlGuidArea.prototype, "children", {
        get: function () {
            return this._children;
        },
        enumerable: false,
        configurable: true
    });
    /**
     * @deprecated The method should not be used
     */
    $ScrollView1$$FlGuidArea.prototype.addChildByName = function (child, name) {
        this._children[name] = child;
        if (this['layout']) {
            this['layout'].addChild(child);
        }
        else {
            this.addChild(child);
        }
    };
    $ScrollView1$$FlGuidArea.prototype.applyTestIDs = function (testId) {
        var _this = this;
        Object.keys(this._children).forEach(function (child) {
            _this._children[child].testId = testId + '_' + child.charAt(0).toUpperCase() + child.slice(1);
            if (_this._children[child].applyTestIDs) {
                _this._children[child].applyTestIDs(_this._children[child].testId);
            }
        });
    };
    $ScrollView1$$FlGuidArea.$$styleContext = {
        classNames: '.sf-flexLayout .card #pgColorAndHtml-flGuidArea',
        defaultClassNames: '.default_common .default_flexLayout',
        userProps: {}
    };
    return $ScrollView1$$FlGuidArea;
}((0, styling_context_1.styleableContainerComponentMixin)(flexlayout_1.default)));
var $ScrollView1$$FlGuidArea$$LblTitleGuid = /** @class */ (function (_super) {
    __extends($ScrollView1$$FlGuidArea$$LblTitleGuid, _super);
    function $ScrollView1$$FlGuidArea$$LblTitleGuid(props) {
        return _super.call(this, { text: 'Guid Test' }) || this;
    }
    $ScrollView1$$FlGuidArea$$LblTitleGuid.$$styleContext = { classNames: '.sf-label', defaultClassNames: '.default_common .default_label', userProps: {} };
    return $ScrollView1$$FlGuidArea$$LblTitleGuid;
}((0, styling_context_1.styleableComponentMixin)(label_1.default)));
var $ScrollView1$$FlGuidArea$$LblGuid = /** @class */ (function (_super) {
    __extends($ScrollView1$$FlGuidArea$$LblGuid, _super);
    function $ScrollView1$$FlGuidArea$$LblGuid(props) {
        return _super.call(this, { text: 'label3' }) || this;
    }
    $ScrollView1$$FlGuidArea$$LblGuid.$$styleContext = {
        classNames: '.sf-label',
        defaultClassNames: '.default_common .default_label',
        userProps: { usePageVariable: true }
    };
    return $ScrollView1$$FlGuidArea$$LblGuid;
}((0, styling_context_1.styleableComponentMixin)(label_1.default)));
var $ScrollView1$$FlHtmlArea = /** @class */ (function (_super) {
    __extends($ScrollView1$$FlHtmlArea, _super);
    function $ScrollView1$$FlHtmlArea(props) {
        var _this = _super.call(this, props) || this;
        _this._children = {};
        _this.addChildByName(new $ScrollView1$$FlHtmlArea$$LblTitleHtml(), 'lblTitleHtml');
        _this.addChildByName(new $ScrollView1$$FlHtmlArea$$TaHtml(), 'taHtml');
        _this.addChildByName(new $ScrollView1$$FlHtmlArea$$FlRowHtml(), 'flRowHtml');
        _this.addChildByName(new $ScrollView1$$FlHtmlArea$$TvHtml(), 'tvHtml');
        _this.addChildByName(new $ScrollView1$$FlHtmlArea$$TvAttrString(), 'tvAttrString');
        return _this;
    }
    Object.defineProperty($ScrollView1$$FlHtmlArea.prototype, "children", {
        get: function () {
            return this._children;
        },
        enumerable: false,
        configurable: true
    });
    /**
     * @deprecated The method should not be used
     */
    $ScrollView1$$FlHtmlArea.prototype.addChildByName = function (child, name) {
        this._children[name] = child;
        if (this['layout']) {
            this['layout'].addChild(child);
        }
        else {
            this.addChild(child);
        }
    };
    $ScrollView1$$FlHtmlArea.prototype.applyTestIDs = function (testId) {
        var _this = this;
        Object.keys(this._children).forEach(function (child) {
            _this._children[child].testId = testId + '_' + child.charAt(0).toUpperCase() + child.slice(1);
            if (_this._children[child].applyTestIDs) {
                _this._children[child].applyTestIDs(_this._children[child].testId);
            }
        });
    };
    $ScrollView1$$FlHtmlArea.$$styleContext = {
        classNames: '.sf-flexLayout .card #pgColorAndHtml-HtmlArea',
        defaultClassNames: '.default_common .default_flexLayout',
        userProps: { height: 400 }
    };
    return $ScrollView1$$FlHtmlArea;
}((0, styling_context_1.styleableContainerComponentMixin)(flexlayout_1.default)));
var $ScrollView1$$FlHtmlArea$$LblTitleHtml = /** @class */ (function (_super) {
    __extends($ScrollView1$$FlHtmlArea$$LblTitleHtml, _super);
    function $ScrollView1$$FlHtmlArea$$LblTitleHtml(props) {
        return _super.call(this, { text: 'Html to Text Test' }) || this;
    }
    $ScrollView1$$FlHtmlArea$$LblTitleHtml.$$styleContext = { classNames: '.sf-label', defaultClassNames: '.default_common .default_label', userProps: {} };
    return $ScrollView1$$FlHtmlArea$$LblTitleHtml;
}((0, styling_context_1.styleableComponentMixin)(label_1.default)));
var $ScrollView1$$FlHtmlArea$$TaHtml = /** @class */ (function (_super) {
    __extends($ScrollView1$$FlHtmlArea$$TaHtml, _super);
    function $ScrollView1$$FlHtmlArea$$TaHtml(props) {
        return _super.call(this, props) || this;
    }
    $ScrollView1$$FlHtmlArea$$TaHtml.$$styleContext = {
        classNames: '.sf-textArea #pgColorAndHtml-txtAreaHtml',
        defaultClassNames: '.default_common .default_textArea',
        userProps: { usePageVariable: true }
    };
    return $ScrollView1$$FlHtmlArea$$TaHtml;
}((0, styling_context_1.styleableComponentMixin)(textarea_1.default)));
var $ScrollView1$$FlHtmlArea$$FlRowHtml = /** @class */ (function (_super) {
    __extends($ScrollView1$$FlHtmlArea$$FlRowHtml, _super);
    function $ScrollView1$$FlHtmlArea$$FlRowHtml(props) {
        var _this = _super.call(this, props) || this;
        _this._children = {};
        _this.addChildByName(new $ScrollView1$$FlHtmlArea$$FlRowHtml$$BtnAttrTexts(), 'btnAttrTexts');
        _this.addChildByName(new $ScrollView1$$FlHtmlArea$$FlRowHtml$$BtnAttrStr(), 'btnAttrStr');
        return _this;
    }
    Object.defineProperty($ScrollView1$$FlHtmlArea$$FlRowHtml.prototype, "children", {
        get: function () {
            return this._children;
        },
        enumerable: false,
        configurable: true
    });
    /**
     * @deprecated The method should not be used
     */
    $ScrollView1$$FlHtmlArea$$FlRowHtml.prototype.addChildByName = function (child, name) {
        this._children[name] = child;
        if (this['layout']) {
            this['layout'].addChild(child);
        }
        else {
            this.addChild(child);
        }
    };
    $ScrollView1$$FlHtmlArea$$FlRowHtml.prototype.applyTestIDs = function (testId) {
        var _this = this;
        Object.keys(this._children).forEach(function (child) {
            _this._children[child].testId = testId + '_' + child.charAt(0).toUpperCase() + child.slice(1);
            if (_this._children[child].applyTestIDs) {
                _this._children[child].applyTestIDs(_this._children[child].testId);
            }
        });
    };
    $ScrollView1$$FlHtmlArea$$FlRowHtml.$$styleContext = {
        classNames: '.sf-flexLayout #pgColorAndHtml-flRow #pgColorAndHtml-flRowHtml',
        defaultClassNames: '.default_common .default_flexLayout',
        userProps: { marginBottom: 10, marginTop: 10 }
    };
    return $ScrollView1$$FlHtmlArea$$FlRowHtml;
}((0, styling_context_1.styleableContainerComponentMixin)(flexlayout_1.default)));
var $ScrollView1$$FlHtmlArea$$FlRowHtml$$BtnAttrTexts = /** @class */ (function (_super) {
    __extends($ScrollView1$$FlHtmlArea$$FlRowHtml$$BtnAttrTexts, _super);
    function $ScrollView1$$FlHtmlArea$$FlRowHtml$$BtnAttrTexts(props) {
        return _super.call(this, { text: 'Attributed Texts' }) || this;
    }
    $ScrollView1$$FlHtmlArea$$FlRowHtml$$BtnAttrTexts.$$styleContext = {
        classNames: '.sf-button .grow',
        defaultClassNames: '.default_common .default_button',
        userProps: { marginRight: 15, usePageVariable: true }
    };
    return $ScrollView1$$FlHtmlArea$$FlRowHtml$$BtnAttrTexts;
}((0, styling_context_1.styleableComponentMixin)(button_1.default)));
var $ScrollView1$$FlHtmlArea$$FlRowHtml$$BtnAttrStr = /** @class */ (function (_super) {
    __extends($ScrollView1$$FlHtmlArea$$FlRowHtml$$BtnAttrStr, _super);
    function $ScrollView1$$FlHtmlArea$$FlRowHtml$$BtnAttrStr(props) {
        return _super.call(this, { text: 'Attributed Strings' }) || this;
    }
    $ScrollView1$$FlHtmlArea$$FlRowHtml$$BtnAttrStr.$$styleContext = {
        classNames: '.sf-button .grow',
        defaultClassNames: '.default_common .default_button',
        userProps: { usePageVariable: true }
    };
    return $ScrollView1$$FlHtmlArea$$FlRowHtml$$BtnAttrStr;
}((0, styling_context_1.styleableComponentMixin)(button_1.default)));
var $ScrollView1$$FlHtmlArea$$TvHtml = /** @class */ (function (_super) {
    __extends($ScrollView1$$FlHtmlArea$$TvHtml, _super);
    function $ScrollView1$$FlHtmlArea$$TvHtml(props) {
        return _super.call(this, { text: '\n' }) || this;
    }
    $ScrollView1$$FlHtmlArea$$TvHtml.$$styleContext = {
        classNames: '.sf-textView #pgColorAndHtml-tvHtml',
        defaultClassNames: '.default_common .default_textView',
        userProps: { backgroundColor: 'rgba( 253, 0, 0, 0.03 )', borderWidth: 1, usePageVariable: true }
    };
    return $ScrollView1$$FlHtmlArea$$TvHtml;
}((0, styling_context_1.styleableComponentMixin)(textview_1.default)));
var $ScrollView1$$FlHtmlArea$$TvAttrString = /** @class */ (function (_super) {
    __extends($ScrollView1$$FlHtmlArea$$TvAttrString, _super);
    function $ScrollView1$$FlHtmlArea$$TvAttrString(props) {
        return _super.call(this, { text: '\n' }) || this;
    }
    $ScrollView1$$FlHtmlArea$$TvAttrString.$$styleContext = {
        classNames: '.sf-textView #pgColorAndHtml-tvHtml',
        defaultClassNames: '.default_common .default_textView',
        userProps: { backgroundColor: 'rgba( 14, 3, 252, 0.04 )', borderWidth: 1, usePageVariable: true }
    };
    return $ScrollView1$$FlHtmlArea$$TvAttrString;
}((0, styling_context_1.styleableComponentMixin)(textview_1.default)));
var $ScrollView1$$FlNativeStyleArea = /** @class */ (function (_super) {
    __extends($ScrollView1$$FlNativeStyleArea, _super);
    function $ScrollView1$$FlNativeStyleArea(props) {
        var _this = _super.call(this, props) || this;
        _this._children = {};
        _this.addChildByName(new $ScrollView1$$FlNativeStyleArea$$LblTitleGetNativeStyle(), 'lblTitleGetNativeStyle');
        _this.addChildByName(new $ScrollView1$$FlNativeStyleArea$$BtnGetNativeStyle(), 'btnGetNativeStyle');
        _this.addChildByName(new $ScrollView1$$FlNativeStyleArea$$BtnGradientColor(), 'btnGradientColor');
        return _this;
    }
    Object.defineProperty($ScrollView1$$FlNativeStyleArea.prototype, "children", {
        get: function () {
            return this._children;
        },
        enumerable: false,
        configurable: true
    });
    /**
     * @deprecated The method should not be used
     */
    $ScrollView1$$FlNativeStyleArea.prototype.addChildByName = function (child, name) {
        this._children[name] = child;
        if (this['layout']) {
            this['layout'].addChild(child);
        }
        else {
            this.addChild(child);
        }
    };
    $ScrollView1$$FlNativeStyleArea.prototype.applyTestIDs = function (testId) {
        var _this = this;
        Object.keys(this._children).forEach(function (child) {
            _this._children[child].testId = testId + '_' + child.charAt(0).toUpperCase() + child.slice(1);
            if (_this._children[child].applyTestIDs) {
                _this._children[child].applyTestIDs(_this._children[child].testId);
            }
        });
    };
    $ScrollView1$$FlNativeStyleArea.$$styleContext = {
        classNames: '.sf-flexLayout .card',
        defaultClassNames: '.default_common .default_flexLayout',
        userProps: { height: 170 }
    };
    return $ScrollView1$$FlNativeStyleArea;
}((0, styling_context_1.styleableContainerComponentMixin)(flexlayout_1.default)));
var $ScrollView1$$FlNativeStyleArea$$LblTitleGetNativeStyle = /** @class */ (function (_super) {
    __extends($ScrollView1$$FlNativeStyleArea$$LblTitleGetNativeStyle, _super);
    function $ScrollView1$$FlNativeStyleArea$$LblTitleGetNativeStyle(props) {
        return _super.call(this, { text: 'getNativeStyle Test' }) || this;
    }
    $ScrollView1$$FlNativeStyleArea$$LblTitleGetNativeStyle.$$styleContext = { classNames: '.sf-label', defaultClassNames: '.default_common .default_label', userProps: {} };
    return $ScrollView1$$FlNativeStyleArea$$LblTitleGetNativeStyle;
}((0, styling_context_1.styleableComponentMixin)(label_1.default)));
var $ScrollView1$$FlNativeStyleArea$$BtnGetNativeStyle = /** @class */ (function (_super) {
    __extends($ScrollView1$$FlNativeStyleArea$$BtnGetNativeStyle, _super);
    function $ScrollView1$$FlNativeStyleArea$$BtnGetNativeStyle(props) {
        return _super.call(this, { text: 'Background color is black' }) || this;
    }
    $ScrollView1$$FlNativeStyleArea$$BtnGetNativeStyle.$$styleContext = {
        classNames: '.sf-button',
        defaultClassNames: '.default_common .default_button',
        userProps: { usePageVariable: true }
    };
    return $ScrollView1$$FlNativeStyleArea$$BtnGetNativeStyle;
}((0, styling_context_1.styleableComponentMixin)(button_1.default)));
var $ScrollView1$$FlNativeStyleArea$$BtnGradientColor = /** @class */ (function (_super) {
    __extends($ScrollView1$$FlNativeStyleArea$$BtnGradientColor, _super);
    function $ScrollView1$$FlNativeStyleArea$$BtnGradientColor(props) {
        return _super.call(this, { text: 'Background color is gradient' }) || this;
    }
    $ScrollView1$$FlNativeStyleArea$$BtnGradientColor.$$styleContext = {
        classNames: '.sf-button',
        defaultClassNames: '.default_common .default_button',
        userProps: { usePageVariable: true }
    };
    return $ScrollView1$$FlNativeStyleArea$$BtnGradientColor;
}((0, styling_context_1.styleableComponentMixin)(button_1.default)));
//# sourceMappingURL=index.js.map