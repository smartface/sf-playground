"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.tab4 = exports.tab3 = exports.tab2 = exports.tab1 = exports.tab0 = void 0;
var page1_1 = __importDefault(require("pages/page1"));
var pgMapView_1 = __importDefault(require("pages/pgMapView"));
var pgMapViewRadius_1 = __importDefault(require("pages/pgMapViewRadius"));
var pgZoomableImageView_1 = __importDefault(require("pages/pgZoomableImageView"));
var pgMapViewRegion_1 = __importDefault(require("pages/pgMapViewRegion"));
var pgHeaderImageAndItems_1 = __importDefault(require("pages/pgHeaderImageAndItems"));
var pgArt_1 = __importDefault(require("pages/pgArt"));
var pgFileUpload_1 = __importDefault(require("pages/pgFileUpload"));
var pgListViewIndex_1 = __importDefault(require("pages/pgListViewIndex"));
var pgSwitch_1 = __importDefault(require("pages/pgSwitch"));
var page2_1 = __importDefault(require("pages/page2"));
var pageHideShow_1 = __importDefault(require("pages/pageHideShow"));
var pgChart_1 = __importDefault(require("pages/pgChart"));
var pgLogin_1 = __importDefault(require("pages/pgLogin"));
var pgButtonPress_1 = __importDefault(require("pages/pgButtonPress"));
var pgWebSocket_1 = __importDefault(require("pages/pgWebSocket"));
var pgBadgeAnimation_1 = __importDefault(require("pages/pgBadgeAnimation"));
var pgHeaderSearch_1 = __importDefault(require("pages/pgHeaderSearch"));
var pgNoTouch_1 = __importDefault(require("pages/pgNoTouch"));
var pgSafeArea_1 = __importDefault(require("pages/pgSafeArea"));
var pgMapRegion_1 = __importDefault(require("pages/pgMapRegion"));
var pgSpriteView_1 = __importDefault(require("pages/pgSpriteView"));
var pgServiceCall_1 = __importDefault(require("pages/pgServiceCall"));
var pgWebView_1 = __importDefault(require("pages/pgWebView"));
var pgLocationManagment_1 = __importDefault(require("pages/pgLocationManagment"));
var pgAppleDevices_1 = __importDefault(require("pages/pgAppleDevices"));
var pgYogaTest_1 = __importDefault(require("pages/pgYogaTest"));
var pgColorAndHtml_1 = __importDefault(require("pages/pgColorAndHtml"));
var pgModalTest_1 = __importDefault(require("pages/pgModalTest"));
var pgOTP_1 = __importDefault(require("pages/pgOTP"));
var pgSSLPinning_1 = __importDefault(require("pages/pgSSLPinning"));
var pgListViewMaterial_1 = __importDefault(require("pages/pgListViewMaterial"));
var pgPhotoPicker_1 = __importDefault(require("pages/pgPhotoPicker"));
var pgDynamicSize_1 = __importDefault(require("pages/pgDynamicSize"));
var pgComponentFromCode_1 = __importDefault(require("pages/pgComponentFromCode"));
var pgGlide_1 = __importDefault(require("pages/pgGlide"));
var pgNativeFunctions_1 = __importDefault(require("pages/pgNativeFunctions"));
var pgTouchConfiguration_1 = __importDefault(require("pages/pgTouchConfiguration"));
var pgToastMessage_1 = __importDefault(require("pages/pgToastMessage"));
var pgHttp_1 = __importDefault(require("pages/pgHttp"));
var pgFile_1 = __importDefault(require("pages/pgFile"));
var pgSound_1 = __importDefault(require("pages/pgSound"));
var pgAsyncTask_1 = __importDefault(require("pages/pgAsyncTask"));
var pgCrypto_1 = __importDefault(require("pages/pgCrypto"));
var pgSpeechRecognizer_1 = __importDefault(require("pages/pgSpeechRecognizer"));
var pgApplicationEvents_1 = __importDefault(require("pages/pgApplicationEvents"));
var pgRangeSliderAndSlider_1 = __importDefault(require("pages/pgRangeSliderAndSlider"));
var pgTimePicker_1 = __importDefault(require("pages/pgTimePicker"));
var pgViewGroup_1 = __importDefault(require("pages/pgViewGroup"));
var pgBlurView_1 = __importDefault(require("pages/pgBlurView"));
var pgLabel_1 = __importDefault(require("pages/pgLabel"));
var pgTextBox_1 = __importDefault(require("pages/pgTextBox"));
var pgListView_1 = __importDefault(require("pages/pgListView"));
var pgModalBottomSheet_1 = __importDefault(require("pages/pgModalBottomSheet"));
var pgPicker_1 = __importDefault(require("pages/pgPicker"));
var pgGridView_1 = __importDefault(require("pages/pgGridView"));
var pgShimmerFlexLayout_1 = __importDefault(require("pages/pgShimmerFlexLayout"));
var pgTabbarController_1 = __importDefault(require("pages/pgTabbarController"));
var pgListviewDragDrop_1 = __importDefault(require("pages/pgListviewDragDrop"));
var pgListviewZebra_1 = __importDefault(require("pages/pgListviewZebra"));
var pgListviewSticky_1 = __importDefault(require("pages/pgListviewSticky"));
var pgListviewSwipe_1 = __importDefault(require("pages/pgListviewSwipe"));
var pgListviewPagination_1 = __importDefault(require("pages/pgListviewPagination"));
var pgListviewMultipleLvi_1 = __importDefault(require("pages/pgListviewMultipleLvi"));
var pgGridViewFullSpan_1 = __importDefault(require("pages/pgGridViewFullSpan"));
var pgGridViewHorizontalCard_1 = __importDefault(require("pages/pgGridViewHorizontalCard"));
var pgGridViewPagination_1 = __importDefault(require("pages/pgGridViewPagination"));
var pgGridViewRowRange_1 = __importDefault(require("pages/pgGridViewRowRange"));
var pgTouchHandling_1 = __importDefault(require("pages/pgTouchHandling"));
var pgContacts_1 = __importDefault(require("pages/pgContacts"));
var pgMultimedia_1 = __importDefault(require("pages/pgMultimedia"));
var pgBlob_1 = __importDefault(require("pages/pgBlob"));
var pgSecureData_1 = __importDefault(require("pages/pgSecureData"));
var pgShare_1 = __importDefault(require("pages/pgShare"));
var pgTimer_1 = __importDefault(require("pages/pgTimer"));
var pgActivityIndicator_1 = __importDefault(require("pages/pgActivityIndicator"));
var pgAlertView_1 = __importDefault(require("pages/pgAlertView"));
var pgImageView_1 = __importDefault(require("pages/pgImageView"));
var pgScrollView_1 = __importDefault(require("pages/pgScrollView"));
var pgLiveMediaPlayer_1 = __importDefault(require("pages/pgLiveMediaPlayer"));
var pgTextArea_1 = __importDefault(require("pages/pgTextArea"));
var pgFlexLayout_1 = __importDefault(require("pages/pgFlexLayout"));
var pgMaterialTextBox_1 = __importDefault(require("pages/pgMaterialTextBox"));
var pgQuickLook_1 = __importDefault(require("pages/pgQuickLook"));
var pgGifImageView_1 = __importDefault(require("pages/pgGifImageView"));
var pgWebBrowser_1 = __importDefault(require("pages/pgWebBrowser"));
var pgView_1 = __importDefault(require("pages/pgView"));
var pgSelectablePicker_1 = __importDefault(require("pages/pgSelectablePicker"));
var pgCallDetection_1 = __importDefault(require("pages/pgCallDetection"));
var pgVideoView_1 = __importDefault(require("pages/pgVideoView"));
var pgStatusBar_1 = __importDefault(require("pages/pgStatusBar"));
var pgHeaderBar_1 = __importDefault(require("pages/pgHeaderBar"));
var pgSearchView_1 = __importDefault(require("pages/pgSearchView"));
var pgEmailComposer_1 = __importDefault(require("pages/pgEmailComposer"));
var pgDatePicker_1 = __importDefault(require("pages/pgDatePicker"));
var pgLiveMediaPublisher_1 = __importDefault(require("pages/pgLiveMediaPublisher"));
var pgButton_1 = __importDefault(require("pages/pgButton"));
var pgAxios_1 = __importDefault(require("pages/pgAxios"));
var pgSystem_1 = __importDefault(require("pages/pgSystem"));
var pgScreen_1 = __importDefault(require("pages/pgScreen"));
var pgHardware_1 = __importDefault(require("pages/pgHardware"));
var pgAccelerometer_1 = __importDefault(require("pages/pgAccelerometer"));
var pgDialog_1 = __importDefault(require("pages/pgDialog"));
var pgXHR_1 = __importDefault(require("pages/pgXHR"));
var pgScrollViewInsideScrollView_1 = __importDefault(require("pages/pgScrollViewInsideScrollView"));
var pgListViewExtendShrink_1 = __importDefault(require("pages/pgListViewExtendShrink"));
var pgListViewDynamicHeight_1 = __importDefault(require("pages/pgListViewDynamicHeight"));
var pgI18N_1 = __importDefault(require("pages/pgI18N"));
var pgBarcodeScanner_1 = __importDefault(require("pages/pgBarcodeScanner"));
var pgCalendar_1 = __importDefault(require("pages/pgCalendar"));
var pgForm_1 = __importDefault(require("pages/pgForm"));
var pgFetch_1 = __importDefault(require("pages/pgFetch"));
var pgOrientation_1 = __importDefault(require("pages/pgOrientation"));
var pgLabelFlexShrink_1 = __importDefault(require("pages/pgLabelFlexShrink"));
var pgSSLPinningHttp_1 = __importDefault(require("pages/pgSSLPinningHttp"));
exports.tab0 = {
    name: 'Native',
    imageName: 'sfnative.png',
    tabIndex: 0,
    pages: [
        pgSearchView_1.default,
        pgMapView_1.default,
        pgMapViewRadius_1.default,
        pgMapRegion_1.default,
        pgShimmerFlexLayout_1.default,
        pgTabbarController_1.default,
        pgListviewDragDrop_1.default,
        pgListviewZebra_1.default,
        pgListviewSticky_1.default,
        pgListviewSwipe_1.default,
        pgListviewPagination_1.default,
        pgListviewMultipleLvi_1.default,
        pgListViewExtendShrink_1.default,
        pgListViewDynamicHeight_1.default,
        pgMapViewRegion_1.default,
        pgHeaderImageAndItems_1.default,
        pgCrypto_1.default,
        pgSwitch_1.default,
        pageHideShow_1.default,
        pgNativeFunctions_1.default,
        pgAccelerometer_1.default,
        pgDialog_1.default,
        pgToastMessage_1.default,
        pgHardware_1.default,
        pgHttp_1.default,
        pgFile_1.default,
        pgSound_1.default,
        pgAsyncTask_1.default,
        pgRangeSliderAndSlider_1.default,
        pgListView_1.default,
        pgSystem_1.default,
        pgScreen_1.default,
        pgGridView_1.default,
        pgPicker_1.default,
        pgTimePicker_1.default,
        pgViewGroup_1.default,
        pgBlurView_1.default,
        pgLabel_1.default,
        pgTextBox_1.default,
        pgSpeechRecognizer_1.default,
        pgGridViewFullSpan_1.default,
        pgGridViewHorizontalCard_1.default,
        pgGridViewPagination_1.default,
        pgGridViewRowRange_1.default,
        pgContacts_1.default,
        pgMultimedia_1.default,
        pgBlob_1.default,
        pgSecureData_1.default,
        pgShare_1.default,
        pgTimer_1.default,
        pgActivityIndicator_1.default,
        pgAlertView_1.default,
        pgImageView_1.default,
        pgScrollView_1.default,
        pgLiveMediaPlayer_1.default,
        pgLiveMediaPublisher_1.default,
        pgTextArea_1.default,
        pgFlexLayout_1.default,
        pgMaterialTextBox_1.default,
        pgQuickLook_1.default,
        pgGifImageView_1.default,
        pgWebBrowser_1.default,
        pgView_1.default,
        pgSelectablePicker_1.default,
        pgCallDetection_1.default,
        pgVideoView_1.default,
        pgStatusBar_1.default,
        pgHeaderBar_1.default,
        pgEmailComposer_1.default,
        pgDatePicker_1.default,
        pgWebView_1.default,
        pgButton_1.default,
        pgLabelFlexShrink_1.default
    ]
};
exports.tab1 = {
    name: 'Utility',
    imageName: 'utility.png',
    tabIndex: 1,
    pages: [pgXHR_1.default, pgPhotoPicker_1.default, pgArt_1.default, pgChart_1.default, pgWebSocket_1.default, pgServiceCall_1.default, pgLocationManagment_1.default, pgAppleDevices_1.default, pgColorAndHtml_1.default, pgSSLPinning_1.default, pgAxios_1.default, pgFetch_1.default, pgSSLPinningHttp_1.default]
};
exports.tab2 = {
    name: 'Modules',
    imageName: 'modules.png',
    tabIndex: 2,
    pages: [pgListViewMaterial_1.default, pgBarcodeScanner_1.default, pgZoomableImageView_1.default, pgListViewIndex_1.default, pgSpriteView_1.default, pgCalendar_1.default, pgI18N_1.default]
};
exports.tab3 = {
    name: 'Router',
    imageName: 'router.png',
    tabIndex: 3,
    pages: [pgModalTest_1.default, pgModalBottomSheet_1.default]
};
exports.tab4 = {
    name: 'Misc',
    imageName: 'misc.png',
    tabIndex: 4,
    pages: [
        pgYogaTest_1.default,
        page1_1.default,
        page2_1.default,
        pgLogin_1.default,
        pgHeaderSearch_1.default,
        pgNoTouch_1.default,
        pgSafeArea_1.default,
        pgOTP_1.default,
        pgGlide_1.default,
        pgTouchConfiguration_1.default,
        pgApplicationEvents_1.default,
        pgFileUpload_1.default,
        pgBadgeAnimation_1.default,
        pgTouchHandling_1.default,
        pgOrientation_1.default,
        pgComponentFromCode_1.default,
        pgButtonPress_1.default,
        pgDynamicSize_1.default,
        pgScrollViewInsideScrollView_1.default,
        pgListViewExtendShrink_1.default,
        pgForm_1.default
    ]
};
//# sourceMappingURL=tabs.js.map